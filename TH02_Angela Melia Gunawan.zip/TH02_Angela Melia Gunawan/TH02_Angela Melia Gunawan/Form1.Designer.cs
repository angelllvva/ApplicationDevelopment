﻿namespace TH02_Angela_Melia_Gunawan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_kata1 = new System.Windows.Forms.Label();
            this.lb_kata2 = new System.Windows.Forms.Label();
            this.lb_kata3 = new System.Windows.Forms.Label();
            this.lb_kata4 = new System.Windows.Forms.Label();
            this.lb_kata5 = new System.Windows.Forms.Label();
            this.tBox_kata1 = new System.Windows.Forms.TextBox();
            this.tBox_kata2 = new System.Windows.Forms.TextBox();
            this.tBox_kata3 = new System.Windows.Forms.TextBox();
            this.tBox_kata4 = new System.Windows.Forms.TextBox();
            this.tBox_kata5 = new System.Windows.Forms.TextBox();
            this.btn_Play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_kata1
            // 
            this.lb_kata1.AutoSize = true;
            this.lb_kata1.Location = new System.Drawing.Point(339, 135);
            this.lb_kata1.Name = "lb_kata1";
            this.lb_kata1.Size = new System.Drawing.Size(64, 20);
            this.lb_kata1.TabIndex = 0;
            this.lb_kata1.Text = "Word 1:";
            // 
            // lb_kata2
            // 
            this.lb_kata2.AutoSize = true;
            this.lb_kata2.Location = new System.Drawing.Point(339, 167);
            this.lb_kata2.Name = "lb_kata2";
            this.lb_kata2.Size = new System.Drawing.Size(64, 20);
            this.lb_kata2.TabIndex = 1;
            this.lb_kata2.Text = "Word 2:";
            // 
            // lb_kata3
            // 
            this.lb_kata3.AutoSize = true;
            this.lb_kata3.Location = new System.Drawing.Point(339, 198);
            this.lb_kata3.Name = "lb_kata3";
            this.lb_kata3.Size = new System.Drawing.Size(64, 20);
            this.lb_kata3.TabIndex = 2;
            this.lb_kata3.Text = "Word 3:";
            // 
            // lb_kata4
            // 
            this.lb_kata4.AutoSize = true;
            this.lb_kata4.Location = new System.Drawing.Point(339, 230);
            this.lb_kata4.Name = "lb_kata4";
            this.lb_kata4.Size = new System.Drawing.Size(64, 20);
            this.lb_kata4.TabIndex = 3;
            this.lb_kata4.Text = "Word 4:";
            // 
            // lb_kata5
            // 
            this.lb_kata5.AutoSize = true;
            this.lb_kata5.Location = new System.Drawing.Point(339, 263);
            this.lb_kata5.Name = "lb_kata5";
            this.lb_kata5.Size = new System.Drawing.Size(64, 20);
            this.lb_kata5.TabIndex = 4;
            this.lb_kata5.Text = "Word 5:";
            // 
            // tBox_kata1
            // 
            this.tBox_kata1.Location = new System.Drawing.Point(413, 132);
            this.tBox_kata1.Name = "tBox_kata1";
            this.tBox_kata1.Size = new System.Drawing.Size(134, 26);
            this.tBox_kata1.TabIndex = 5;
            // 
            // tBox_kata2
            // 
            this.tBox_kata2.Location = new System.Drawing.Point(413, 164);
            this.tBox_kata2.Name = "tBox_kata2";
            this.tBox_kata2.Size = new System.Drawing.Size(134, 26);
            this.tBox_kata2.TabIndex = 6;
            // 
            // tBox_kata3
            // 
            this.tBox_kata3.Location = new System.Drawing.Point(413, 196);
            this.tBox_kata3.Name = "tBox_kata3";
            this.tBox_kata3.Size = new System.Drawing.Size(134, 26);
            this.tBox_kata3.TabIndex = 7;
            // 
            // tBox_kata4
            // 
            this.tBox_kata4.Location = new System.Drawing.Point(413, 228);
            this.tBox_kata4.Name = "tBox_kata4";
            this.tBox_kata4.Size = new System.Drawing.Size(134, 26);
            this.tBox_kata4.TabIndex = 8;
            // 
            // tBox_kata5
            // 
            this.tBox_kata5.Location = new System.Drawing.Point(413, 260);
            this.tBox_kata5.Name = "tBox_kata5";
            this.tBox_kata5.Size = new System.Drawing.Size(134, 26);
            this.tBox_kata5.TabIndex = 9;
            // 
            // btn_Play
            // 
            this.btn_Play.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Play.Location = new System.Drawing.Point(396, 312);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(105, 31);
            this.btn_Play.TabIndex = 10;
            this.btn_Play.Text = "Play!";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 495);
            this.Controls.Add(this.btn_Play);
            this.Controls.Add(this.tBox_kata5);
            this.Controls.Add(this.tBox_kata4);
            this.Controls.Add(this.tBox_kata3);
            this.Controls.Add(this.tBox_kata2);
            this.Controls.Add(this.tBox_kata1);
            this.Controls.Add(this.lb_kata5);
            this.Controls.Add(this.lb_kata4);
            this.Controls.Add(this.lb_kata3);
            this.Controls.Add(this.lb_kata2);
            this.Controls.Add(this.lb_kata1);
            this.MaximumSize = new System.Drawing.Size(914, 551);
            this.MinimumSize = new System.Drawing.Size(914, 551);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Tebak Kata";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_kata1;
        private System.Windows.Forms.Label lb_kata2;
        private System.Windows.Forms.Label lb_kata3;
        private System.Windows.Forms.Label lb_kata4;
        private System.Windows.Forms.Label lb_kata5;
        private System.Windows.Forms.TextBox tBox_kata1;
        private System.Windows.Forms.TextBox tBox_kata2;
        private System.Windows.Forms.TextBox tBox_kata3;
        private System.Windows.Forms.TextBox tBox_kata4;
        private System.Windows.Forms.TextBox tBox_kata5;
        private System.Windows.Forms.Button btn_Play;
    }
}

