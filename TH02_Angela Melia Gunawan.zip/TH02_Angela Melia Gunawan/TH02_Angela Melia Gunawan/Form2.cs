﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Angela_Melia_Gunawan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            lb_Tebak.Text = Form1.tebakKata; //variabel yang dibawa dari Form1

            List<char> karakter = new List<char>(); //list untuk menampung tiap karakter dari kata yang akan ditebak

            foreach (char alphabet in Form1.tebakKata)
            {
                karakter.Add(alphabet);
            }
        }

        //cek tiap alfabet

        private void btn_A_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'A')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'A'.ToString());
                }
            }
            Win();
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'S')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'S'.ToString());
                }
            }
            Win();
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'D')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'D'.ToString());
                }
            }
            Win();
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'F')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'F'.ToString());
                }
            }
            Win();
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'G')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'G'.ToString());
                }
            }
            Win();
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'H')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'H'.ToString());
                }
            }
            Win();
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'J')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'J'.ToString());
                }
            }
            Win();
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'K')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'K'.ToString());
                }
            }
            Win();
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'L')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'L'.ToString());
                }
            }
            Win();
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Q')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'Q'.ToString());
                }
            }
            Win();
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'W')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'W'.ToString());
                }
            }
            Win();
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'E')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'E'.ToString());
                }
            }
            Win();
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'R')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'R'.ToString());
                }
            }
            Win();
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'T')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'T'.ToString());
                }
            }
            Win();
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Y')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'Y'.ToString());
                }
            }
            Win();
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'U')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'U'.ToString());
                }
            }
            Win();
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'I')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'I'.ToString());
                }
            }
            Win();
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'O')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'O'.ToString());
                }
            }
            Win();
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'P')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'P'.ToString());
                }
            }
            Win();
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Z')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'Z'.ToString());
                }
            }
            Win();
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'X')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'X'.ToString());
                }
            }
            Win();
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'C')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'C'.ToString());
                }
            }
            Win();
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'V')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'V'.ToString());
                }
            }
            Win();
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'B')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'B'.ToString());
                }
            }
            Win();
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'N')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'N'.ToString());
                }
            }
            Win();
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'M')
                {
                    i = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(i, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(i, 'M'.ToString());
                }
            }
            Win();
        }
        
        //method untuk cek menang

        private void Win()
        {
            if (lb_Tebak1.Text[0] != '_' && lb_Tebak1.Text[2] != '_' && lb_Tebak1.Text[4] != '_' && lb_Tebak1.Text[6] != '_' && lb_Tebak1.Text[8] != '_')
            {
                MessageBox.Show("You Win");
                
                Form1 form = new Form1();
                form.Show();

                this.Hide();
            }
        }
    }
}