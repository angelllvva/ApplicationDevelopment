﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Angela_Melia_Gunawan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            lb_Tebak.Text = Form1.tebakKata; //variabel yang dibawa dari Form1

            List<char> karakter = new List<char>(); //list untuk menampung tiap karakter dari kata yang akan ditebak

            foreach (char alphabet in Form1.tebakKata)
            {
                karakter.Add(alphabet);
            }
        }

        //cek tiap alfabet

        int count = 0;

        private void btn_A_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'A')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'A'.ToString());
                }
            }
            Win();
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'S')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'S'.ToString());
                }
            }
            Win();
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'D')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'D'.ToString());
                }
            }
            Win();
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'F')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'F'.ToString());
                }
            }
            Win();
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'G')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'G'.ToString());
                }
            }
            Win();
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'H')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'H'.ToString());
                }
            }
            Win();
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'J')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'J'.ToString());
                }
            }
            Win();
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'K')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'K'.ToString());
                }
            }
            Win();
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'L')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'L'.ToString());
                }
            }
            Win();
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Q')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'Q'.ToString());
                }
            }
            Win();
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'W')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'W'.ToString());
                }
            }
            Win();
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'E')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'E'.ToString());
                }
            }
            Win();
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'R')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'R'.ToString());
                }
            }
            Win();
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'T')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'T'.ToString());
                }
            }
            Win();
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Y')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'Y'.ToString());
                }
            }
            Win();
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'U')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'U'.ToString());
                }
            }
            Win();
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'I')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'I'.ToString());
                }
            }
            Win();
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'O')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'O'.ToString());
                }
            }
            Win();
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'P')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'P'.ToString());
                }
            }
            Win();
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'Z')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'Z'.ToString());
                }
            }
            Win();
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'X')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'X'.ToString());
                }
            }
            Win();
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'C')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'C'.ToString());
                }
            }
            Win();
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'V')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'V'.ToString());
                }
            }
            Win();
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'B')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'B'.ToString());
                }
            }
            Win();
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'N')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'N'.ToString());
                }
            }
            Win();
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (Form1.tebakKata[i] == 'M')
                {
                    count = i + i;
                    lb_Tebak1.Text = lb_Tebak1.Text.Remove(count, 1);
                    lb_Tebak1.Text = lb_Tebak1.Text.Insert(count, 'M'.ToString());
                }
            }
            Win();
        }
        
        //method untuk cek menang

        private void Win()
        {
            if (lb_Tebak1.Text[0] != '_' && lb_Tebak1.Text[2] != '_' && lb_Tebak1.Text[4] != '_' && lb_Tebak1.Text[6] != '_' && lb_Tebak1.Text[8] != '_')
            {
                MessageBox.Show("You Win");
                
                Form1 form = new Form1();
                form.Show();

                this.Hide();
            }
        }
    }
}