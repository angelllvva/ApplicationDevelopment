﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Angela_Melia_Gunawan
{
    public partial class Form1 : Form
    {
        public static string tebakKata = ""; //buat variabel public untuk dibawa dari Form1 ke Form2

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            //pengecekan apakah ada error atau masuk in game

            if (tBox_kata1.Text.Length == 5 && tBox_kata2.Text.Length == 5 && tBox_kata3.Text.Length == 5 && tBox_kata4.Text.Length == 5 && tBox_kata5.Text.Length == 5) //cek apakah masing-masing kata memiliki 5 huruf
            {
                string[] tampung = new string[5]; //array untuk menampung masing-masing kata
                tampung[0] = tBox_kata1.Text;
                tampung[1] = tBox_kata2.Text;
                tampung[2] = tBox_kata3.Text;
                tampung[3] = tBox_kata4.Text;
                tampung[4] = tBox_kata5.Text;

                //pengecekan apakah input ada angka

                int angka = 0;

                for (int i = 0; i < 5; i++)
                {
                    if (tampung[i].Any(char.IsDigit))
                    {
                        angka++;
                    }
                }

                if (tBox_kata1.Text == tBox_kata2.Text || tBox_kata1.Text == tBox_kata3.Text || tBox_kata1.Text == tBox_kata4.Text || tBox_kata1.Text == tBox_kata5.Text || tBox_kata2.Text == tBox_kata3.Text || tBox_kata2.Text == tBox_kata4.Text || tBox_kata2.Text == tBox_kata5.Text || tBox_kata3.Text== tBox_kata4.Text || tBox_kata3.Text == tBox_kata5.Text || tBox_kata4.Text == tBox_kata5.Text) //cek apakah ada kata yang kembar
                {
                    MessageBox.Show("There's still an error");
                }
                else if (angka != 0)
                {
                    MessageBox.Show("There's still an error");
                }
                else
                {
                    Random rnd = new Random();
                    int randomValue = rnd.Next(0, 5); //random kata dengan indeks ke berapa yang akan ditebak
                    tebakKata = tampung[randomValue].ToUpper();

                    MessageBox.Show("Let's Play");

                    Form2 form = new Form2(); //menampilkan Form2
                    form.Show();

                    this.Hide(); //menutup Form1
                }
            }
            else
            {
                MessageBox.Show("There's still an error");
            }
        }
    }
}