﻿namespace TH03_Angela_Melia_Gunawan
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tBox_Password = new System.Windows.Forms.TextBox();
            this.lb_Password = new System.Windows.Forms.Label();
            this.tBox_Username = new System.Windows.Forms.TextBox();
            this.lb_Username = new System.Windows.Forms.Label();
            this.lb_UCBank = new System.Windows.Forms.Label();
            this.btn_Register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tBox_Password
            // 
            this.tBox_Password.Location = new System.Drawing.Point(378, 213);
            this.tBox_Password.Name = "tBox_Password";
            this.tBox_Password.Size = new System.Drawing.Size(141, 26);
            this.tBox_Password.TabIndex = 11;
            // 
            // lb_Password
            // 
            this.lb_Password.AutoSize = true;
            this.lb_Password.Location = new System.Drawing.Point(276, 216);
            this.lb_Password.Name = "lb_Password";
            this.lb_Password.Size = new System.Drawing.Size(82, 20);
            this.lb_Password.TabIndex = 10;
            this.lb_Password.Text = "Password:";
            // 
            // tBox_Username
            // 
            this.tBox_Username.Location = new System.Drawing.Point(378, 174);
            this.tBox_Username.Name = "tBox_Username";
            this.tBox_Username.Size = new System.Drawing.Size(141, 26);
            this.tBox_Username.TabIndex = 9;
            // 
            // lb_Username
            // 
            this.lb_Username.AutoSize = true;
            this.lb_Username.Location = new System.Drawing.Point(276, 177);
            this.lb_Username.Name = "lb_Username";
            this.lb_Username.Size = new System.Drawing.Size(87, 20);
            this.lb_Username.TabIndex = 8;
            this.lb_Username.Text = "Username:";
            // 
            // lb_UCBank
            // 
            this.lb_UCBank.AutoSize = true;
            this.lb_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank.Location = new System.Drawing.Point(308, 85);
            this.lb_UCBank.Name = "lb_UCBank";
            this.lb_UCBank.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank.TabIndex = 7;
            this.lb_UCBank.Text = "UC Bank";
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(348, 267);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(107, 32);
            this.btn_Register.TabIndex = 13;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Register);
            this.Controls.Add(this.tBox_Password);
            this.Controls.Add(this.lb_Password);
            this.Controls.Add(this.tBox_Username);
            this.Controls.Add(this.lb_Username);
            this.Controls.Add(this.lb_UCBank);
            this.Name = "Form2";
            this.Text = "UC Bank";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tBox_Password;
        private System.Windows.Forms.Label lb_Password;
        private System.Windows.Forms.TextBox tBox_Username;
        private System.Windows.Forms.Label lb_Username;
        private System.Windows.Forms.Label lb_UCBank;
        private System.Windows.Forms.Button btn_Register;
    }
}