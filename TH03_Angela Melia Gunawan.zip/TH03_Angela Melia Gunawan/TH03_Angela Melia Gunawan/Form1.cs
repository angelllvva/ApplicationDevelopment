﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace TH03_Angela_Melia_Gunawan
{
    public partial class Form1 : Form
    {
        CultureInfo culture = new CultureInfo("id-ID");

        List<string> listUsername = new List<string>();
        List<string> listPassword = new List<string>();
        List<int> listMoney = new List<int>();

        int accountLogin = 0;
        int totalAccount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            pnl_Login.Visible = false;
            pnl_Register.Visible = true;
        }

        private void btn_Register2_Click(object sender, EventArgs e)
        {
            int countRegister = 0;

            for (int i = 0; i < listUsername.Count; i++)
            {
                if (tBox_Username2.Text == listUsername[i])
                {
                    countRegister++;
                }
            }
            
            if (countRegister != 0)
            {
                MessageBox.Show("Username has been used");
            }
            else if (tBox_Username2.Text == "" || tBox_Password2.Text == "")
            {
                MessageBox.Show("Registration failed \rPlease check your input");
            }
            else
            {
                MessageBox.Show("Register Successful");
                
                totalAccount++;

                listUsername.Add(tBox_Username2.Text);
                listPassword.Add(tBox_Password2.Text);
                listMoney.Add(0);

                tBox_Username2.Clear();
                tBox_Password2.Clear();

                tBox_Username.Clear();
                tBox_Password.Clear();

                pnl_Login.Visible = true;
                pnl_Register.Visible = false;
            }
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            int counter = 0;
            for (int i = 0; i < listUsername.Count; i++)
            {
                if (tBox_Username.Text == listUsername[i] && tBox_Password.Text == listPassword[i])
                {
                    counter++;
                    accountLogin = i;
                }
            }

            if (totalAccount == 0)
            {
                MessageBox.Show("Username and Password not Found!");
                tBox_Username.Clear();
                tBox_Password.Clear();
            }
            else if (tBox_Username.Text == "" || tBox_Password.Text == "")
            {
                MessageBox.Show("Login failed \rPlease check your input");
            }
            else if (counter != 0)
            {
                MessageBox.Show("Login Successful");

                pnl_MainView.Visible = true;
                pnl_Login.Visible = false;

                lb_Total.Text = listMoney[accountLogin].ToString("C", culture);

                tBox_Username.Clear();
                tBox_Password.Clear();
            }
            else
            {
                MessageBox.Show("Username and Password not Found!");
                tBox_Username.Clear();
                tBox_Password.Clear();
            }
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            pnl_Deposit.Visible = true;
            pnl_MainView.Visible = false;

            tBox_DepositAmount.Clear();
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            pnl_Withdrawal.Visible = true;
            pnl_MainView.Visible = false;

            tBox_WithdrawalAmount.Clear();
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            pnl_Login.Visible = true;
            pnl_MainView.Visible = false;

            tBox_Username.Clear();
            tBox_Password.Clear();
        }

        private void btn_LogOut2_Click(object sender, EventArgs e)
        {
            pnl_Login.Visible = true;
            pnl_Deposit.Visible = false;

            tBox_Username.Clear();
            tBox_Password.Clear();
        }

        private void btn_LogOut3_Click(object sender, EventArgs e)
        {
            pnl_Login.Visible = true;
            pnl_Withdrawal.Visible = false;

            tBox_Username.Clear();
            tBox_Password.Clear();
        }

        private void btn_DepositAmount_Click(object sender, EventArgs e)
        {
            int depoMoney = Convert.ToInt32(tBox_DepositAmount.Text); 
            
            if (tBox_DepositAmount.Text == "0")
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
                tBox_DepositAmount.Clear();
            }
            else if (tBox_DepositAmount.Text == "")
            {
                MessageBox.Show("Please Input Deposit Amount");
            }
            else
            {
                MessageBox.Show("Successfully Add Deposit");
                
                listMoney[accountLogin] += depoMoney;

                lb_Total.Text = listMoney[accountLogin].ToString("C", culture);
                lb_Total2.Text = listMoney[accountLogin].ToString("C", culture);

                pnl_MainView.Visible = true;
                pnl_Deposit.Visible = false;
            }
        }

        private void btn_WithdrawalAmount_Click(object sender, EventArgs e)
        {
            lb_Total2.Text = listMoney[accountLogin].ToString("C", culture);

            int withdrawMoney = Convert.ToInt32(tBox_WithdrawalAmount.Text);

            if (tBox_WithdrawalAmount.Text == "0")
            {
                MessageBox.Show("Withdraw Amount Can't be Less Than 1");
                tBox_WithdrawalAmount.Clear();
            }
            else if (listMoney[accountLogin] < withdrawMoney)
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance.");
                tBox_WithdrawalAmount.Clear();
            }
            else if (tBox_WithdrawalAmount.Text == "")
            {
                MessageBox.Show("Please Input Withdrawal Amount");
            }
            else
            {
                MessageBox.Show("Successfully Withdraw");

                listMoney[accountLogin] -= withdrawMoney;

                lb_Total.Text = listMoney[accountLogin].ToString("C", culture);
                lb_Total2.Text = listMoney[accountLogin].ToString("C", culture);

                pnl_MainView.Visible = true;
                pnl_Withdrawal.Visible = false;
            }
        }
    }
}