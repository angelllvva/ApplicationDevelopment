﻿namespace TH03_Angela_Melia_Gunawan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Login = new System.Windows.Forms.Panel();
            this.btn_Register = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.tBox_Password = new System.Windows.Forms.TextBox();
            this.lb_Password = new System.Windows.Forms.Label();
            this.tBox_Username = new System.Windows.Forms.TextBox();
            this.lb_Username = new System.Windows.Forms.Label();
            this.lb_UCBank = new System.Windows.Forms.Label();
            this.pnl_Register = new System.Windows.Forms.Panel();
            this.btn_Register2 = new System.Windows.Forms.Button();
            this.tBox_Password2 = new System.Windows.Forms.TextBox();
            this.lb_Password2 = new System.Windows.Forms.Label();
            this.tBox_Username2 = new System.Windows.Forms.TextBox();
            this.lb_Username2 = new System.Windows.Forms.Label();
            this.lb_UCBank2 = new System.Windows.Forms.Label();
            this.pnl_MainView = new System.Windows.Forms.Panel();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.lb_Total = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lb_Balance = new System.Windows.Forms.Label();
            this.lb_UCBank3 = new System.Windows.Forms.Label();
            this.lb_UCBank4 = new System.Windows.Forms.Label();
            this.btn_DepositAmount = new System.Windows.Forms.Button();
            this.lb_DepositAmount = new System.Windows.Forms.Label();
            this.tBox_DepositAmount = new System.Windows.Forms.TextBox();
            this.pnl_Deposit = new System.Windows.Forms.Panel();
            this.btn_LogOut2 = new System.Windows.Forms.Button();
            this.pnl_Withdrawal = new System.Windows.Forms.Panel();
            this.lb_Total2 = new System.Windows.Forms.Label();
            this.lb_Balance2 = new System.Windows.Forms.Label();
            this.btn_LogOut3 = new System.Windows.Forms.Button();
            this.tBox_WithdrawalAmount = new System.Windows.Forms.TextBox();
            this.lb_WithdrawalAmount = new System.Windows.Forms.Label();
            this.btn_WithdrawalAmount = new System.Windows.Forms.Button();
            this.lb_UCBank5 = new System.Windows.Forms.Label();
            this.pnl_Login.SuspendLayout();
            this.pnl_Register.SuspendLayout();
            this.pnl_MainView.SuspendLayout();
            this.pnl_Deposit.SuspendLayout();
            this.pnl_Withdrawal.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Login
            // 
            this.pnl_Login.Controls.Add(this.btn_Register);
            this.pnl_Login.Controls.Add(this.btn_Login);
            this.pnl_Login.Controls.Add(this.tBox_Password);
            this.pnl_Login.Controls.Add(this.lb_Password);
            this.pnl_Login.Controls.Add(this.tBox_Username);
            this.pnl_Login.Controls.Add(this.lb_Username);
            this.pnl_Login.Controls.Add(this.lb_UCBank);
            this.pnl_Login.Location = new System.Drawing.Point(180, 79);
            this.pnl_Login.Name = "pnl_Login";
            this.pnl_Login.Size = new System.Drawing.Size(421, 281);
            this.pnl_Login.TabIndex = 7;
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(161, 234);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(107, 32);
            this.btn_Register.TabIndex = 13;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(161, 196);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(107, 32);
            this.btn_Login.TabIndex = 12;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // tBox_Password
            // 
            this.tBox_Password.Location = new System.Drawing.Point(191, 142);
            this.tBox_Password.Name = "tBox_Password";
            this.tBox_Password.Size = new System.Drawing.Size(141, 26);
            this.tBox_Password.TabIndex = 11;
            // 
            // lb_Password
            // 
            this.lb_Password.AutoSize = true;
            this.lb_Password.Location = new System.Drawing.Point(89, 145);
            this.lb_Password.Name = "lb_Password";
            this.lb_Password.Size = new System.Drawing.Size(82, 20);
            this.lb_Password.TabIndex = 10;
            this.lb_Password.Text = "Password:";
            // 
            // tBox_Username
            // 
            this.tBox_Username.Location = new System.Drawing.Point(191, 103);
            this.tBox_Username.Name = "tBox_Username";
            this.tBox_Username.Size = new System.Drawing.Size(141, 26);
            this.tBox_Username.TabIndex = 9;
            // 
            // lb_Username
            // 
            this.lb_Username.AutoSize = true;
            this.lb_Username.Location = new System.Drawing.Point(89, 106);
            this.lb_Username.Name = "lb_Username";
            this.lb_Username.Size = new System.Drawing.Size(87, 20);
            this.lb_Username.TabIndex = 8;
            this.lb_Username.Text = "Username:";
            // 
            // lb_UCBank
            // 
            this.lb_UCBank.AutoSize = true;
            this.lb_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank.Location = new System.Drawing.Point(121, 14);
            this.lb_UCBank.Name = "lb_UCBank";
            this.lb_UCBank.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank.TabIndex = 7;
            this.lb_UCBank.Text = "UC Bank";
            // 
            // pnl_Register
            // 
            this.pnl_Register.Controls.Add(this.btn_Register2);
            this.pnl_Register.Controls.Add(this.tBox_Password2);
            this.pnl_Register.Controls.Add(this.lb_Password2);
            this.pnl_Register.Controls.Add(this.tBox_Username2);
            this.pnl_Register.Controls.Add(this.lb_Username2);
            this.pnl_Register.Controls.Add(this.lb_UCBank2);
            this.pnl_Register.Location = new System.Drawing.Point(180, 79);
            this.pnl_Register.Name = "pnl_Register";
            this.pnl_Register.Size = new System.Drawing.Size(421, 281);
            this.pnl_Register.TabIndex = 20;
            this.pnl_Register.Visible = false;
            // 
            // btn_Register2
            // 
            this.btn_Register2.Location = new System.Drawing.Point(161, 196);
            this.btn_Register2.Name = "btn_Register2";
            this.btn_Register2.Size = new System.Drawing.Size(107, 32);
            this.btn_Register2.TabIndex = 13;
            this.btn_Register2.Text = "Register";
            this.btn_Register2.UseVisualStyleBackColor = true;
            this.btn_Register2.Click += new System.EventHandler(this.btn_Register2_Click);
            // 
            // tBox_Password2
            // 
            this.tBox_Password2.Location = new System.Drawing.Point(191, 142);
            this.tBox_Password2.Name = "tBox_Password2";
            this.tBox_Password2.Size = new System.Drawing.Size(141, 26);
            this.tBox_Password2.TabIndex = 11;
            // 
            // lb_Password2
            // 
            this.lb_Password2.AutoSize = true;
            this.lb_Password2.Location = new System.Drawing.Point(89, 145);
            this.lb_Password2.Name = "lb_Password2";
            this.lb_Password2.Size = new System.Drawing.Size(82, 20);
            this.lb_Password2.TabIndex = 10;
            this.lb_Password2.Text = "Password:";
            // 
            // tBox_Username2
            // 
            this.tBox_Username2.Location = new System.Drawing.Point(191, 103);
            this.tBox_Username2.Name = "tBox_Username2";
            this.tBox_Username2.Size = new System.Drawing.Size(141, 26);
            this.tBox_Username2.TabIndex = 9;
            // 
            // lb_Username2
            // 
            this.lb_Username2.AutoSize = true;
            this.lb_Username2.Location = new System.Drawing.Point(89, 106);
            this.lb_Username2.Name = "lb_Username2";
            this.lb_Username2.Size = new System.Drawing.Size(87, 20);
            this.lb_Username2.TabIndex = 8;
            this.lb_Username2.Text = "Username:";
            // 
            // lb_UCBank2
            // 
            this.lb_UCBank2.AutoSize = true;
            this.lb_UCBank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank2.Location = new System.Drawing.Point(121, 14);
            this.lb_UCBank2.Name = "lb_UCBank2";
            this.lb_UCBank2.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank2.TabIndex = 7;
            this.lb_UCBank2.Text = "UC Bank";
            // 
            // pnl_MainView
            // 
            this.pnl_MainView.Controls.Add(this.btn_Withdraw);
            this.pnl_MainView.Controls.Add(this.lb_Total);
            this.pnl_MainView.Controls.Add(this.btn_LogOut);
            this.pnl_MainView.Controls.Add(this.btn_Deposit);
            this.pnl_MainView.Controls.Add(this.lb_Balance);
            this.pnl_MainView.Controls.Add(this.lb_UCBank3);
            this.pnl_MainView.Location = new System.Drawing.Point(180, 79);
            this.pnl_MainView.Name = "pnl_MainView";
            this.pnl_MainView.Size = new System.Drawing.Size(421, 281);
            this.pnl_MainView.TabIndex = 21;
            this.pnl_MainView.Visible = false;
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(161, 204);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(107, 32);
            this.btn_Withdraw.TabIndex = 16;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // lb_Total
            // 
            this.lb_Total.AutoSize = true;
            this.lb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total.Location = new System.Drawing.Point(165, 110);
            this.lb_Total.Name = "lb_Total";
            this.lb_Total.Size = new System.Drawing.Size(82, 26);
            this.lb_Total.TabIndex = 15;
            this.lb_Total.Text = "Rp0,00";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(301, 66);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(107, 32);
            this.btn_LogOut.TabIndex = 14;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(161, 166);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(107, 32);
            this.btn_Deposit.TabIndex = 13;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lb_Balance
            // 
            this.lb_Balance.AutoSize = true;
            this.lb_Balance.Location = new System.Drawing.Point(92, 115);
            this.lb_Balance.Name = "lb_Balance";
            this.lb_Balance.Size = new System.Drawing.Size(67, 20);
            this.lb_Balance.TabIndex = 8;
            this.lb_Balance.Text = "Balance";
            // 
            // lb_UCBank3
            // 
            this.lb_UCBank3.AutoSize = true;
            this.lb_UCBank3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank3.Location = new System.Drawing.Point(121, 14);
            this.lb_UCBank3.Name = "lb_UCBank3";
            this.lb_UCBank3.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank3.TabIndex = 7;
            this.lb_UCBank3.Text = "UC Bank";
            // 
            // lb_UCBank4
            // 
            this.lb_UCBank4.AutoSize = true;
            this.lb_UCBank4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank4.Location = new System.Drawing.Point(121, 14);
            this.lb_UCBank4.Name = "lb_UCBank4";
            this.lb_UCBank4.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank4.TabIndex = 8;
            this.lb_UCBank4.Text = "UC Bank";
            // 
            // btn_DepositAmount
            // 
            this.btn_DepositAmount.Location = new System.Drawing.Point(161, 180);
            this.btn_DepositAmount.Name = "btn_DepositAmount";
            this.btn_DepositAmount.Size = new System.Drawing.Size(107, 32);
            this.btn_DepositAmount.TabIndex = 14;
            this.btn_DepositAmount.Text = "Deposit";
            this.btn_DepositAmount.UseVisualStyleBackColor = true;
            this.btn_DepositAmount.Click += new System.EventHandler(this.btn_DepositAmount_Click);
            // 
            // lb_DepositAmount
            // 
            this.lb_DepositAmount.AutoSize = true;
            this.lb_DepositAmount.Location = new System.Drawing.Point(131, 109);
            this.lb_DepositAmount.Name = "lb_DepositAmount";
            this.lb_DepositAmount.Size = new System.Drawing.Size(169, 20);
            this.lb_DepositAmount.TabIndex = 15;
            this.lb_DepositAmount.Text = "Input Deposit Amount:";
            // 
            // tBox_DepositAmount
            // 
            this.tBox_DepositAmount.Location = new System.Drawing.Point(139, 142);
            this.tBox_DepositAmount.Name = "tBox_DepositAmount";
            this.tBox_DepositAmount.Size = new System.Drawing.Size(151, 26);
            this.tBox_DepositAmount.TabIndex = 16;
            // 
            // pnl_Deposit
            // 
            this.pnl_Deposit.Controls.Add(this.btn_LogOut2);
            this.pnl_Deposit.Controls.Add(this.tBox_DepositAmount);
            this.pnl_Deposit.Controls.Add(this.lb_DepositAmount);
            this.pnl_Deposit.Controls.Add(this.btn_DepositAmount);
            this.pnl_Deposit.Controls.Add(this.lb_UCBank4);
            this.pnl_Deposit.Location = new System.Drawing.Point(180, 79);
            this.pnl_Deposit.Name = "pnl_Deposit";
            this.pnl_Deposit.Size = new System.Drawing.Size(500, 328);
            this.pnl_Deposit.TabIndex = 17;
            this.pnl_Deposit.Visible = false;
            // 
            // btn_LogOut2
            // 
            this.btn_LogOut2.Location = new System.Drawing.Point(301, 66);
            this.btn_LogOut2.Name = "btn_LogOut2";
            this.btn_LogOut2.Size = new System.Drawing.Size(107, 32);
            this.btn_LogOut2.TabIndex = 17;
            this.btn_LogOut2.Text = "Log Out";
            this.btn_LogOut2.UseVisualStyleBackColor = true;
            this.btn_LogOut2.Click += new System.EventHandler(this.btn_LogOut2_Click);
            // 
            // pnl_Withdrawal
            // 
            this.pnl_Withdrawal.Controls.Add(this.lb_Total2);
            this.pnl_Withdrawal.Controls.Add(this.lb_Balance2);
            this.pnl_Withdrawal.Controls.Add(this.btn_LogOut3);
            this.pnl_Withdrawal.Controls.Add(this.tBox_WithdrawalAmount);
            this.pnl_Withdrawal.Controls.Add(this.lb_WithdrawalAmount);
            this.pnl_Withdrawal.Controls.Add(this.btn_WithdrawalAmount);
            this.pnl_Withdrawal.Controls.Add(this.lb_UCBank5);
            this.pnl_Withdrawal.Location = new System.Drawing.Point(180, 79);
            this.pnl_Withdrawal.Name = "pnl_Withdrawal";
            this.pnl_Withdrawal.Size = new System.Drawing.Size(519, 345);
            this.pnl_Withdrawal.TabIndex = 18;
            this.pnl_Withdrawal.Visible = false;
            // 
            // lb_Total2
            // 
            this.lb_Total2.AutoSize = true;
            this.lb_Total2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total2.Location = new System.Drawing.Point(165, 110);
            this.lb_Total2.Name = "lb_Total2";
            this.lb_Total2.Size = new System.Drawing.Size(82, 26);
            this.lb_Total2.TabIndex = 19;
            this.lb_Total2.Text = "Rp0,00";
            // 
            // lb_Balance2
            // 
            this.lb_Balance2.AutoSize = true;
            this.lb_Balance2.Location = new System.Drawing.Point(92, 115);
            this.lb_Balance2.Name = "lb_Balance2";
            this.lb_Balance2.Size = new System.Drawing.Size(67, 20);
            this.lb_Balance2.TabIndex = 18;
            this.lb_Balance2.Text = "Balance";
            // 
            // btn_LogOut3
            // 
            this.btn_LogOut3.Location = new System.Drawing.Point(301, 66);
            this.btn_LogOut3.Name = "btn_LogOut3";
            this.btn_LogOut3.Size = new System.Drawing.Size(107, 32);
            this.btn_LogOut3.TabIndex = 17;
            this.btn_LogOut3.Text = "Log Out";
            this.btn_LogOut3.UseVisualStyleBackColor = true;
            this.btn_LogOut3.Click += new System.EventHandler(this.btn_LogOut3_Click);
            // 
            // tBox_WithdrawalAmount
            // 
            this.tBox_WithdrawalAmount.Location = new System.Drawing.Point(139, 185);
            this.tBox_WithdrawalAmount.Name = "tBox_WithdrawalAmount";
            this.tBox_WithdrawalAmount.Size = new System.Drawing.Size(151, 26);
            this.tBox_WithdrawalAmount.TabIndex = 16;
            // 
            // lb_WithdrawalAmount
            // 
            this.lb_WithdrawalAmount.AutoSize = true;
            this.lb_WithdrawalAmount.Location = new System.Drawing.Point(121, 152);
            this.lb_WithdrawalAmount.Name = "lb_WithdrawalAmount";
            this.lb_WithdrawalAmount.Size = new System.Drawing.Size(192, 20);
            this.lb_WithdrawalAmount.TabIndex = 15;
            this.lb_WithdrawalAmount.Text = "Input Withdrawal Amount:";
            // 
            // btn_WithdrawalAmount
            // 
            this.btn_WithdrawalAmount.Location = new System.Drawing.Point(161, 223);
            this.btn_WithdrawalAmount.Name = "btn_WithdrawalAmount";
            this.btn_WithdrawalAmount.Size = new System.Drawing.Size(107, 32);
            this.btn_WithdrawalAmount.TabIndex = 14;
            this.btn_WithdrawalAmount.Text = "Withdrawal";
            this.btn_WithdrawalAmount.UseVisualStyleBackColor = true;
            this.btn_WithdrawalAmount.Click += new System.EventHandler(this.btn_WithdrawalAmount_Click);
            // 
            // lb_UCBank5
            // 
            this.lb_UCBank5.AutoSize = true;
            this.lb_UCBank5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank5.Location = new System.Drawing.Point(121, 14);
            this.lb_UCBank5.Name = "lb_UCBank5";
            this.lb_UCBank5.Size = new System.Drawing.Size(187, 46);
            this.lb_UCBank5.TabIndex = 8;
            this.lb_UCBank5.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_Withdrawal);
            this.Controls.Add(this.pnl_Deposit);
            this.Controls.Add(this.pnl_MainView);
            this.Controls.Add(this.pnl_Register);
            this.Controls.Add(this.pnl_Login);
            this.Name = "Form1";
            this.Text = "UC Bank";
            this.pnl_Login.ResumeLayout(false);
            this.pnl_Login.PerformLayout();
            this.pnl_Register.ResumeLayout(false);
            this.pnl_Register.PerformLayout();
            this.pnl_MainView.ResumeLayout(false);
            this.pnl_MainView.PerformLayout();
            this.pnl_Deposit.ResumeLayout(false);
            this.pnl_Deposit.PerformLayout();
            this.pnl_Withdrawal.ResumeLayout(false);
            this.pnl_Withdrawal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Login;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox tBox_Password;
        private System.Windows.Forms.Label lb_Password;
        private System.Windows.Forms.TextBox tBox_Username;
        private System.Windows.Forms.Label lb_Username;
        private System.Windows.Forms.Label lb_UCBank;
        private System.Windows.Forms.Panel pnl_Register;
        private System.Windows.Forms.Button btn_Register2;
        private System.Windows.Forms.TextBox tBox_Password2;
        private System.Windows.Forms.Label lb_Password2;
        private System.Windows.Forms.TextBox tBox_Username2;
        private System.Windows.Forms.Label lb_Username2;
        private System.Windows.Forms.Label lb_UCBank2;
        private System.Windows.Forms.Panel pnl_MainView;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lb_Balance;
        private System.Windows.Forms.Label lb_UCBank3;
        private System.Windows.Forms.Label lb_Total;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Label lb_UCBank4;
        private System.Windows.Forms.Button btn_DepositAmount;
        private System.Windows.Forms.Label lb_DepositAmount;
        private System.Windows.Forms.TextBox tBox_DepositAmount;
        private System.Windows.Forms.Panel pnl_Deposit;
        private System.Windows.Forms.Button btn_LogOut2;
        private System.Windows.Forms.Panel pnl_Withdrawal;
        private System.Windows.Forms.Button btn_LogOut3;
        private System.Windows.Forms.TextBox tBox_WithdrawalAmount;
        private System.Windows.Forms.Label lb_WithdrawalAmount;
        private System.Windows.Forms.Button btn_WithdrawalAmount;
        private System.Windows.Forms.Label lb_UCBank5;
        private System.Windows.Forms.Label lb_Total2;
        private System.Windows.Forms.Label lb_Balance2;
    }
}

