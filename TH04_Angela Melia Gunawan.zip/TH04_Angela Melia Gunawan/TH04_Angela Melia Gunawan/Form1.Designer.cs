﻿namespace TH04_Angela_Melia_Gunawan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_SoccerTeam = new System.Windows.Forms.Label();
            this.lb_Country = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.cmbBox_Country = new System.Windows.Forms.ComboBox();
            this.cmbBox_Team = new System.Windows.Forms.ComboBox();
            this.lb_AddTeam = new System.Windows.Forms.Label();
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.lb_TeamCountry = new System.Windows.Forms.Label();
            this.lb_TeamCity = new System.Windows.Forms.Label();
            this.tBox_TeamName = new System.Windows.Forms.TextBox();
            this.tBox_TeamCountry = new System.Windows.Forms.TextBox();
            this.tBox_TeamCity = new System.Windows.Forms.TextBox();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.tBox_PlayerNumber = new System.Windows.Forms.TextBox();
            this.tBox_PlayerName = new System.Windows.Forms.TextBox();
            this.lb_PlayerPosition = new System.Windows.Forms.Label();
            this.lb_PlayerNumber = new System.Windows.Forms.Label();
            this.lb_PlayerName = new System.Windows.Forms.Label();
            this.lb_AddPlayer = new System.Windows.Forms.Label();
            this.cmbBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.listBox_Player = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_SoccerTeam
            // 
            this.lb_SoccerTeam.AutoSize = true;
            this.lb_SoccerTeam.Location = new System.Drawing.Point(42, 35);
            this.lb_SoccerTeam.Name = "lb_SoccerTeam";
            this.lb_SoccerTeam.Size = new System.Drawing.Size(132, 20);
            this.lb_SoccerTeam.TabIndex = 0;
            this.lb_SoccerTeam.Text = "Soccer Team List";
            // 
            // lb_Country
            // 
            this.lb_Country.AutoSize = true;
            this.lb_Country.Location = new System.Drawing.Point(42, 71);
            this.lb_Country.Name = "lb_Country";
            this.lb_Country.Size = new System.Drawing.Size(127, 20);
            this.lb_Country.TabIndex = 1;
            this.lb_Country.Text = "Choose Country:";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(42, 110);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(112, 20);
            this.lb_Team.TabIndex = 2;
            this.lb_Team.Text = "Choose Team:";
            // 
            // cmbBox_Country
            // 
            this.cmbBox_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBox_Country.FormattingEnabled = true;
            this.cmbBox_Country.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.cmbBox_Country.Location = new System.Drawing.Point(187, 68);
            this.cmbBox_Country.Name = "cmbBox_Country";
            this.cmbBox_Country.Size = new System.Drawing.Size(131, 28);
            this.cmbBox_Country.TabIndex = 3;
            this.cmbBox_Country.SelectedIndexChanged += new System.EventHandler(this.cmbBox_Country_SelectedIndexChanged);
            // 
            // cmbBox_Team
            // 
            this.cmbBox_Team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBox_Team.FormattingEnabled = true;
            this.cmbBox_Team.Location = new System.Drawing.Point(187, 107);
            this.cmbBox_Team.Name = "cmbBox_Team";
            this.cmbBox_Team.Size = new System.Drawing.Size(131, 28);
            this.cmbBox_Team.TabIndex = 4;
            this.cmbBox_Team.SelectedIndexChanged += new System.EventHandler(this.cmbBox_Team_SelectedIndexChanged);
            // 
            // lb_AddTeam
            // 
            this.lb_AddTeam.AutoSize = true;
            this.lb_AddTeam.Location = new System.Drawing.Point(453, 35);
            this.lb_AddTeam.Name = "lb_AddTeam";
            this.lb_AddTeam.Size = new System.Drawing.Size(103, 20);
            this.lb_AddTeam.TabIndex = 5;
            this.lb_AddTeam.Text = "Adding Team";
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Location = new System.Drawing.Point(363, 71);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(99, 20);
            this.lb_TeamName.TabIndex = 6;
            this.lb_TeamName.Text = "Team Name:";
            // 
            // lb_TeamCountry
            // 
            this.lb_TeamCountry.AutoSize = true;
            this.lb_TeamCountry.Location = new System.Drawing.Point(363, 110);
            this.lb_TeamCountry.Name = "lb_TeamCountry";
            this.lb_TeamCountry.Size = new System.Drawing.Size(112, 20);
            this.lb_TeamCountry.TabIndex = 7;
            this.lb_TeamCountry.Text = "Team Country:";
            // 
            // lb_TeamCity
            // 
            this.lb_TeamCity.AutoSize = true;
            this.lb_TeamCity.Location = new System.Drawing.Point(363, 149);
            this.lb_TeamCity.Name = "lb_TeamCity";
            this.lb_TeamCity.Size = new System.Drawing.Size(83, 20);
            this.lb_TeamCity.TabIndex = 8;
            this.lb_TeamCity.Text = "Team City:";
            // 
            // tBox_TeamName
            // 
            this.tBox_TeamName.Location = new System.Drawing.Point(485, 68);
            this.tBox_TeamName.Name = "tBox_TeamName";
            this.tBox_TeamName.Size = new System.Drawing.Size(144, 26);
            this.tBox_TeamName.TabIndex = 9;
            // 
            // tBox_TeamCountry
            // 
            this.tBox_TeamCountry.Location = new System.Drawing.Point(485, 107);
            this.tBox_TeamCountry.Name = "tBox_TeamCountry";
            this.tBox_TeamCountry.Size = new System.Drawing.Size(144, 26);
            this.tBox_TeamCountry.TabIndex = 10;
            // 
            // tBox_TeamCity
            // 
            this.tBox_TeamCity.Location = new System.Drawing.Point(485, 146);
            this.tBox_TeamCity.Name = "tBox_TeamCity";
            this.tBox_TeamCity.Size = new System.Drawing.Size(144, 26);
            this.tBox_TeamCity.TabIndex = 11;
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(457, 187);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(92, 31);
            this.btn_AddTeam.TabIndex = 12;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Location = new System.Drawing.Point(773, 187);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(92, 31);
            this.btn_AddPlayer.TabIndex = 20;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // tBox_PlayerNumber
            // 
            this.tBox_PlayerNumber.Location = new System.Drawing.Point(805, 107);
            this.tBox_PlayerNumber.Name = "tBox_PlayerNumber";
            this.tBox_PlayerNumber.Size = new System.Drawing.Size(144, 26);
            this.tBox_PlayerNumber.TabIndex = 18;
            // 
            // tBox_PlayerName
            // 
            this.tBox_PlayerName.Location = new System.Drawing.Point(805, 68);
            this.tBox_PlayerName.Name = "tBox_PlayerName";
            this.tBox_PlayerName.Size = new System.Drawing.Size(144, 26);
            this.tBox_PlayerName.TabIndex = 17;
            // 
            // lb_PlayerPosition
            // 
            this.lb_PlayerPosition.AutoSize = true;
            this.lb_PlayerPosition.Location = new System.Drawing.Point(674, 149);
            this.lb_PlayerPosition.Name = "lb_PlayerPosition";
            this.lb_PlayerPosition.Size = new System.Drawing.Size(116, 20);
            this.lb_PlayerPosition.TabIndex = 16;
            this.lb_PlayerPosition.Text = "Player Position:";
            // 
            // lb_PlayerNumber
            // 
            this.lb_PlayerNumber.AutoSize = true;
            this.lb_PlayerNumber.Location = new System.Drawing.Point(674, 110);
            this.lb_PlayerNumber.Name = "lb_PlayerNumber";
            this.lb_PlayerNumber.Size = new System.Drawing.Size(116, 20);
            this.lb_PlayerNumber.TabIndex = 15;
            this.lb_PlayerNumber.Text = "Player Number:";
            // 
            // lb_PlayerName
            // 
            this.lb_PlayerName.AutoSize = true;
            this.lb_PlayerName.Location = new System.Drawing.Point(674, 71);
            this.lb_PlayerName.Name = "lb_PlayerName";
            this.lb_PlayerName.Size = new System.Drawing.Size(102, 20);
            this.lb_PlayerName.TabIndex = 14;
            this.lb_PlayerName.Text = "Player Name:";
            // 
            // lb_AddPlayer
            // 
            this.lb_AddPlayer.AutoSize = true;
            this.lb_AddPlayer.Location = new System.Drawing.Point(762, 35);
            this.lb_AddPlayer.Name = "lb_AddPlayer";
            this.lb_AddPlayer.Size = new System.Drawing.Size(114, 20);
            this.lb_AddPlayer.TabIndex = 13;
            this.lb_AddPlayer.Text = "Adding Players";
            // 
            // cmbBox_PlayerPosition
            // 
            this.cmbBox_PlayerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBox_PlayerPosition.FormattingEnabled = true;
            this.cmbBox_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cmbBox_PlayerPosition.Location = new System.Drawing.Point(805, 146);
            this.cmbBox_PlayerPosition.Name = "cmbBox_PlayerPosition";
            this.cmbBox_PlayerPosition.Size = new System.Drawing.Size(144, 28);
            this.cmbBox_PlayerPosition.TabIndex = 21;
            // 
            // listBox_Player
            // 
            this.listBox_Player.FormattingEnabled = true;
            this.listBox_Player.ItemHeight = 20;
            this.listBox_Player.Location = new System.Drawing.Point(46, 148);
            this.listBox_Player.Name = "listBox_Player";
            this.listBox_Player.Size = new System.Drawing.Size(272, 164);
            this.listBox_Player.TabIndex = 22;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(46, 318);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(92, 31);
            this.btn_Remove.TabIndex = 23;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 384);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.listBox_Player);
            this.Controls.Add(this.cmbBox_PlayerPosition);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.tBox_PlayerNumber);
            this.Controls.Add(this.tBox_PlayerName);
            this.Controls.Add(this.lb_PlayerPosition);
            this.Controls.Add(this.lb_PlayerNumber);
            this.Controls.Add(this.lb_PlayerName);
            this.Controls.Add(this.lb_AddPlayer);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.tBox_TeamCity);
            this.Controls.Add(this.tBox_TeamCountry);
            this.Controls.Add(this.tBox_TeamName);
            this.Controls.Add(this.lb_TeamCity);
            this.Controls.Add(this.lb_TeamCountry);
            this.Controls.Add(this.lb_TeamName);
            this.Controls.Add(this.lb_AddTeam);
            this.Controls.Add(this.cmbBox_Team);
            this.Controls.Add(this.cmbBox_Country);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Country);
            this.Controls.Add(this.lb_SoccerTeam);
            this.MaximumSize = new System.Drawing.Size(1020, 440);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_SoccerTeam;
        private System.Windows.Forms.Label lb_Country;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.ComboBox cmbBox_Country;
        private System.Windows.Forms.ComboBox cmbBox_Team;
        private System.Windows.Forms.Label lb_AddTeam;
        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.Label lb_TeamCountry;
        private System.Windows.Forms.Label lb_TeamCity;
        private System.Windows.Forms.TextBox tBox_TeamName;
        private System.Windows.Forms.TextBox tBox_TeamCountry;
        private System.Windows.Forms.TextBox tBox_TeamCity;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.TextBox tBox_PlayerNumber;
        private System.Windows.Forms.TextBox tBox_PlayerName;
        private System.Windows.Forms.Label lb_PlayerPosition;
        private System.Windows.Forms.Label lb_PlayerNumber;
        private System.Windows.Forms.Label lb_PlayerName;
        private System.Windows.Forms.Label lb_AddPlayer;
        private System.Windows.Forms.ComboBox cmbBox_PlayerPosition;
        private System.Windows.Forms.ListBox listBox_Player;
        private System.Windows.Forms.Button btn_Remove;
    }
}

