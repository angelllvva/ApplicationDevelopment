﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Angela_Melia_Gunawan
{
    public partial class Form1 : Form
    {
        List<Team> teamList = new List<Team>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //mendeklarasikan negara dan team awal
            Team team1 = new Team("Manchester United", "England", "Manchester");
            Team team2 = new Team("Chelsea", "England", "London");
            Team team3 = new Team("Bayern Munich", "Germany", "München");

            //menambahkan masing-masing team ke teamList
            teamList.Add(team1);
            teamList.Add(team2);
            teamList.Add(team3);

            //mendeklarasikan nama player team1: Manchester United
            Player player1_Team1 = new Player("David De Gea", "01", "GK");
            Player player2_Team1 = new Player("Victor Lindelof", "02", "DF");
            Player player3_Team1 = new Player("Phil Jones", "04", "DF");
            Player player4_Team1 = new Player("Harry Maguire", "05", "DF");
            Player player5_Team1 = new Player("Lisandro Martinez", "06", "DF");
            Player player6_Team1 = new Player("Bruno Fernandez", "08", "MF");
            Player player7_Team1 = new Player("Anthony Martial", "09", "FW");
            Player player8_Team1 = new Player("Marcus Rashford", "10", "FW");
            Player player9_Team1 = new Player("Tyrell Malacia", "12", "DF");
            Player player10_Team1 = new Player("Christian Eriksen", "14", "MF");
            Player player11_Team1 = new Player("Casemiro", "18", "MF");

            //mendeklarasikan nama player team2: Chelsea
            Player player1_Team2 = new Player("Kepa Arrizabalaga", "01", "GK");
            Player player2_Team2 = new Player("Benoît Badiashile", "04", "DF");
            Player player3_Team2 = new Player("Enzo Fernández", "05", "MF");
            Player player4_Team2 = new Player("Thiago Silva", "06", "DF");
            Player player5_Team2 = new Player("N'Golo Kanté", "07", "MF");
            Player player6_Team2 = new Player("Mateo Kovačić", "08", "MF");
            Player player7_Team2 = new Player("Pierre-Emerick Aubameyang", "09", "FW");
            Player player8_Team2 = new Player("Christian Pulisic", "10", "MF");
            Player player9_Team2 = new Player("João Félix", "11", "FW");
            Player player10_Team2 = new Player("Ruben Loftus-Cheek", "12", "MF");
            Player player11_Team2 = new Player("Raheem Sterling", "17", "MF");

            //mendeklarasikan nama player team3: Bayern Munich
            Player player1_Team3 = new Player("Manuel Neuer", "01", "GK");
            Player player2_Team3 = new Player("Dayot Upamecano", "02", "DF");
            Player player3_Team3 = new Player("Matthijs de Ligt", "04", "DF");
            Player player4_Team3 = new Player("Benjamin Pavard", "05", "DF");
            Player player5_Team3 = new Player("Joshua Kimmich", "06", "MF");
            Player player6_Team3 = new Player("Serge Gnabry", "07", "FW");
            Player player7_Team3 = new Player("Leon Goretzka", "08", "MF");
            Player player8_Team3 = new Player("Leroy Sané", "10", "FW");
            Player player9_Team3 = new Player("Paul Wanner", "14", "MF");
            Player player10_Team3 = new Player("Lucas Hernandez", "21", "DF");
            Player player11_Team3 = new Player("Thomas Müller", "25", "FW");

            //menambahkan masing-masing player team ke playerList
            team1.players.Add(player1_Team1);
            team1.players.Add(player2_Team1);
            team1.players.Add(player3_Team1);
            team1.players.Add(player4_Team1);
            team1.players.Add(player5_Team1);
            team1.players.Add(player6_Team1);
            team1.players.Add(player7_Team1);
            team1.players.Add(player8_Team1);
            team1.players.Add(player9_Team1);
            team1.players.Add(player10_Team1);
            team1.players.Add(player11_Team1);

            team2.players.Add(player1_Team2);
            team2.players.Add(player2_Team2);
            team2.players.Add(player3_Team2);
            team2.players.Add(player4_Team2);
            team2.players.Add(player5_Team2);
            team2.players.Add(player6_Team2);
            team2.players.Add(player7_Team2);
            team2.players.Add(player8_Team2);
            team2.players.Add(player9_Team2);
            team2.players.Add(player10_Team2);
            team2.players.Add(player11_Team2);

            team3.players.Add(player1_Team3);
            team3.players.Add(player2_Team3);
            team3.players.Add(player3_Team3);
            team3.players.Add(player4_Team3);
            team3.players.Add(player5_Team3);
            team3.players.Add(player6_Team3);
            team3.players.Add(player7_Team3);
            team3.players.Add(player8_Team3);
            team3.players.Add(player9_Team3);
            team3.players.Add(player10_Team3);
            team3.players.Add(player11_Team3);
        }

        //memunculkan drop down list team sesuai negara
        private void cmbBox_Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbBox_Team.Items.Clear();
            listBox_Player.Items.Clear();
            foreach (Team team in teamList)
            {
                if (team.teamCountry == cmbBox_Country.SelectedItem.ToString())
                {
                    cmbBox_Team.Items.Add(team.teamName);
                }
            }
        }

        //memunculkan listbox players sesuai nama team
        private void cmbBox_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_Player.Items.Clear();
            foreach (Team team in teamList)
            {
                if (team.teamName == cmbBox_Team.SelectedItem.ToString())
                {
                    foreach (Player players in team.players)
                    {
                        listBox_Player.Items.Add($"({players.playerNum}) {players.playerName}, {players.playerPos}");
                    }
                }
            }
        }

        //remove salah satu player dari listbox
        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (listBox_Player.Items.Count <= 11)
            {
                MessageBox.Show("Unable to remove player if players less than or equal to 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                listBox_Player.Items.Remove(listBox_Player.SelectedItem);
            }
        }

        //menambahkan team, negara dan kota baru ke drop box country dan team
        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            int teamCheck = 0;
            foreach (Team team in teamList)
            {
                if (team.teamName == tBox_TeamName.Text)
                {
                    teamCheck++;
                    break;
                }
            }

            if (tBox_TeamName.Text == "" || tBox_TeamCountry.Text == "" || tBox_TeamCity.Text == "")
            {
                MessageBox.Show("All of the fields need to be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (teamCheck != 0)
            {
                MessageBox.Show("Team has already exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Team addTeam = new Team(tBox_TeamName.Text, tBox_TeamCountry.Text, tBox_TeamCity.Text);
                teamList.Add(addTeam);

                foreach (Team team in teamList)
                {
                    if (!cmbBox_Country.Items.Contains(team.teamCountry))
                    {
                        cmbBox_Country.Items.Add(team.teamCountry);
                    }
                }

                foreach (Team team in teamList)
                {
                    if (!cmbBox_Team.Items.Contains(team.teamName) && (team.teamCountry == cmbBox_Country.Text))
                    {
                        cmbBox_Team.Items.Add(team.teamName);
                    }
                }

                MessageBox.Show("Successfully adding team", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tBox_TeamName.Clear();
                tBox_TeamCountry.Clear();
                tBox_TeamCity.Clear();
            }
        }

        //menambahkan nama, nomor dan posisi player baru ke list box player
        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if (tBox_PlayerName.Text == "" || tBox_PlayerNumber.Text == "" || cmbBox_PlayerPosition.SelectedIndex == -1)
            {
                MessageBox.Show("All of the fields need to be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (cmbBox_Country.Text == "" || cmbBox_Team.Text == "")
                {
                    MessageBox.Show("Please choose country and team first", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Player addPlayer = new Player(tBox_PlayerName.Text, tBox_PlayerNumber.Text, cmbBox_PlayerPosition.Text);

                    int playerNameCheck = 0;
                    int playerNumCheck = 0;

                    foreach (Team team in teamList)
                    {
                        if (team.teamName == cmbBox_Team.Text)
                        {
                            foreach (Player player in team.players)
                            {
                                if (addPlayer.playerName == player.playerName)
                                {
                                    playerNameCheck++;
                                    break;
                                }
                                else if (addPlayer.playerNum == player.playerNum)
                                {
                                    playerNumCheck++;
                                    break;
                                }
                            }

                            if (playerNameCheck != 0)
                            {
                                MessageBox.Show("Player with the same name is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (playerNumCheck != 0)
                            {
                                MessageBox.Show("Player with the same number is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (playerNameCheck != 0 && playerNumCheck != 0)
                            {
                                MessageBox.Show("Player with the same name and number is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (playerNameCheck == 0 && playerNumCheck == 0)
                            {
                                team.players.Add(addPlayer);
                                listBox_Player.Items.Clear();
                                foreach (Team teamChoosen in teamList)
                                {
                                    if (teamChoosen.teamName == cmbBox_Team.Text && teamChoosen.teamCountry == cmbBox_Country.Text)
                                    {
                                        foreach (Player players in teamChoosen.players)
                                        {
                                            listBox_Player.Items.Add($"({players.playerNum}) {players.playerName}, {players.playerPos}");
                                            listBox_Player.Sorted = true;
                                        }
                                        break;
                                    }
                                }

                                MessageBox.Show("Successfully adding player", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tBox_PlayerName.Clear();
                                tBox_PlayerNumber.Clear();
                                cmbBox_PlayerPosition.SelectedIndex = -1;
                            }
                        }
                    }
                }
            }
        }
    }
}