﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Angela_Melia_Gunawan
{
    internal class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> players = new List<Player>();

        public Team (string teamName, string teamCountry, string teamCity)        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
        }
    }
}