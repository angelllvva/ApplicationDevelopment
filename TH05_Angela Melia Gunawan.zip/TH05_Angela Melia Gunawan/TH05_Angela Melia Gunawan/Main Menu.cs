﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH05_Angela_Melia_Gunawan
{
    public partial class Main_Menu : Form
    {
        DataTable dataProductSimpan;
        DataTable dataProductTampil;
        DataTable dataCategories;
        List<string> productID = new List<string>();

        int indexProductCurrentRow = 0;
        string categoryID = "";
        string categoryName = "";
        string inputCategory = "";
        string filter = "";
        public Main_Menu()
        {
            InitializeComponent();

            tBox_harga.KeyPress += tBox_harga_KeyPress;
            tBox_stock.KeyPress += tBox_stock_KeyPress;
        }

        private void Main_Menu_Load(object sender, EventArgs e)
        {
            dataProductSimpan = new DataTable();
            dataProductSimpan.Columns.Add("ID Product");
            dataProductSimpan.Columns.Add("Nama Product");
            dataProductSimpan.Columns.Add("Harga");
            dataProductSimpan.Columns.Add("Stock");
            dataProductSimpan.Columns.Add("ID Category");
            dgv_product.DataSource = dataProductSimpan;

            dataCategories = new DataTable();
            dataCategories.Columns.Add("ID Category");
            dataCategories.Columns.Add("Nama Category");
            dgv_category.DataSource = dataCategories;

            dataProductSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dataProductSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dataProductSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dataProductSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dataProductSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dataProductSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dataProductSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dataProductSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dataCategories.Rows.Add("C1", "Jas");
            dataCategories.Rows.Add("C2", "T-Shirt");
            dataCategories.Rows.Add("C3", "Rok");
            dataCategories.Rows.Add("C4", "Celana");
            dataCategories.Rows.Add("C5", "Cawat");
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            int newCategoryID = 0;
            if (dgv_category.Rows.Count != 0)
            {
                string lastCategoryID = dgv_category.Rows[dgv_category.Rows.Count - 1].Cells[0].Value.ToString();
                newCategoryID = Convert.ToInt32(lastCategoryID.Remove(0, 1)) + 1;
            }
            else if (dgv_category.Rows.Count == 0)
            {
                newCategoryID = 1;
            }

            int checkCategory = 0;
            for (int i = 0; i < dgv_category.Rows.Count; i++)
            {
                if (dgv_category.Rows[i].Cells[1].Value.ToString().ToUpper() == tBox_namaCategory.Text.ToUpper())
                {
                    checkCategory++;
                    break;
                }
            }

            if (tBox_namaCategory.Text == "")
            {
                MessageBox.Show("Masukkan nama kategori terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (checkCategory != 0)
            {
                MessageBox.Show("Kategori sudah ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                dataCategories.Rows.Add("C" + newCategoryID.ToString(), tBox_namaCategory.Text);

                cmbBox_category.Items.Clear();
                cmbBox_filter.Items.Clear();
                for (int i = 0; i < dgv_category.Rows.Count; i++)
                {
                    cmbBox_category.Items.Add(dgv_category.Rows[i].Cells[1].Value.ToString());
                    cmbBox_filter.Items.Add(dgv_category.Rows[i].Cells[1].Value.ToString());
                }
            }
        }

        private void dgv_category_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_category.CurrentRow;
            tBox_namaCategory.Text = currentRow.Cells[1].Value.ToString();
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_category.CurrentRow;
            int categoryCheck = 0;
            for (int i = 0; i < dataCategories.Rows.Count; i++)
            {
                if (dataCategories.Rows[i][1].ToString(). Contains(tBox_namaCategory.Text))
                {
                    categoryCheck++;
                }
            }
            if (tBox_namaCategory.Text != "" && categoryCheck != 0)
            {
                int counter = 0;
                int totalRow = dataProductSimpan.Rows.Count;
                for (int i = 0; i < totalRow; i++)
                {
                    if (counter == 0)
                    {
                        if (currentRow.Cells[0].Value.ToString() == dataProductSimpan.Rows[i][4].ToString())
                        {
                            dataProductSimpan.Rows.RemoveAt(i);
                            counter++;
                        }
                    }
                    else if (counter != 0)
                    {
                        if (currentRow.Cells[0].Value.ToString() == dataProductSimpan.Rows[i-counter][4].ToString())
                        {
                            dataProductSimpan.Rows.RemoveAt(i-counter);
                            counter++;
                        }
                    }
                }

                dgv_category.Rows.Remove(currentRow);
                tBox_namaCategory.Clear();

                cmbBox_category.Items.Clear();
                cmbBox_filter.Items.Clear();
                for (int i = 0; i < dgv_category.Rows.Count; i++)
                {
                    cmbBox_category.Items.Add(dgv_category.Rows[i].Cells[1].Value.ToString());
                    cmbBox_filter.Items.Add(dgv_category.Rows[i].Cells[1].Value.ToString());
                }

                tBox_namaProduct.Clear();
                cmbBox_category.Text = "";
                tBox_harga.Clear();
                tBox_stock.Clear();
            }
            else if (categoryCheck == 0)
            {
                tBox_namaCategory.Text = "";
            }
        }

        private void dgv_product_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_product.CurrentRow;
            
            tBox_namaProduct.Text = currentRow.Cells[1].Value.ToString();

            for (int i = 0; i < dgv_category.Rows.Count; i++)
            {
                if (currentRow.Cells[4].Value.ToString() == dgv_category.Rows[i].Cells[0].Value.ToString())
                {
                    categoryName = dgv_category.Rows[i].Cells[1].Value.ToString();
                }
            }

            cmbBox_category.Text = categoryName;
            tBox_harga.Text = currentRow.Cells[2].Value.ToString();
            tBox_stock.Text = currentRow.Cells[3].Value.ToString();

            indexProductCurrentRow = dgv_product.CurrentRow.Index;
        }

        private void tBox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tBox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            int categoryAddNotFound = 0;
            if (!cmbBox_category.Items.Contains(cmbBox_category.Text))
            {
                categoryAddNotFound++;
            }

            if (tBox_namaProduct.Text == "" && cmbBox_category.Text == "" && tBox_harga.Text == "" && tBox_stock.Text == "")
            {
                MessageBox.Show($"Input produk yang mau di-add terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (categoryAddNotFound != 0 || cmbBox_category.Text == "")
            {
                MessageBox.Show("Pilih kategori terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (tBox_namaProduct.Text == "" || cmbBox_category.Text == "" || tBox_harga.Text == "" || tBox_stock.Text == "")
            {
                MessageBox.Show($"Input produk yang mau di-add terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (cmbBox_filter.Text != "")
                {
                    dgv_product.DataSource = dataProductSimpan;
                    AddProduct();
                    cmbBox_filter.Text = "";
                }
                else
                {
                    AddProduct();
                }
            }
        }

        private void AddProduct()
        {
            string product1stCharacter = tBox_namaProduct.Text.Substring(0, 1).ToUpper();
            for (int i = 0; i < dataProductSimpan.Rows.Count; i++)
            {
                if (dataProductSimpan.Rows[i][0].ToString().Contains(product1stCharacter))
                {
                    productID.Add(dataProductSimpan.Rows[i][0].ToString());
                }
            }

            if (productID.Count != 0)
            {
                string lastProductID = productID[productID.Count - 1];
                int newProductID = Convert.ToInt32(lastProductID.Remove(0, 1)) + 1;

                if (newProductID <= 9)
                {
                    Category();
                    dataProductSimpan.Rows.Add(product1stCharacter + "00" + newProductID.ToString(), tBox_namaProduct.Text, tBox_harga.Text, tBox_stock.Text, inputCategory);
                    ClearDetail();
                }
                else if (newProductID >= 10 && newProductID <= 99)
                {
                    Category();
                    dataProductSimpan.Rows.Add(product1stCharacter + "0" + newProductID.ToString(), tBox_namaProduct.Text, tBox_harga.Text, tBox_stock.Text, inputCategory);
                    ClearDetail();
                }
                else if (newProductID >= 100)
                {
                    Category();
                    dataProductSimpan.Rows.Add(product1stCharacter + newProductID.ToString(), tBox_namaProduct.Text, tBox_harga.Text, tBox_stock.Text, inputCategory);
                    ClearDetail();
                }

                productID.Clear();
            }
            else if (productID.Count == 0)
            {
                Category();
                dataProductSimpan.Rows.Add(product1stCharacter + "001", tBox_namaProduct.Text, tBox_harga.Text, tBox_stock.Text, inputCategory);
                ClearDetail();
            }
        }

        private void ClearDetail()
        {
            tBox_namaProduct.Clear();
            cmbBox_category.Text = "";
            tBox_harga.Clear();
            tBox_stock.Clear();
        }

        private void Category()
        {
            for (int i = 0; i < dataCategories.Rows.Count; i++)
            {
                if (dataCategories.Rows[i][1].ToString() == cmbBox_category.Text)
                {
                    inputCategory = dataCategories.Rows[i][0].ToString();
                }
            }
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (tBox_namaProduct.Text != "" && cmbBox_category.Text != "" && tBox_harga.Text != "" && tBox_stock.Text != "")
            {
                if (cmbBox_filter.Text != "")
                {
                    removeProductFilter();
                }
                else
                {
                    removeProductAll();
                }
            }
        }


        private void removeProductFilter()
        {
            dgv_product.DataSource = dataProductSimpan;

            for (int i = 0; i < dataProductSimpan.Rows.Count; i++)
            {
                if (dataProductSimpan.Rows[i][0].ToString() == dataProductTampil.Rows[indexProductCurrentRow][0].ToString())
                {
                    dgv_product.Rows.Remove(dgv_product.Rows[i]);
                }
            }

            cmbBox_filter.Text = "";
            ClearDetail();
        }

        private void removeProductAll()
        {
            DataGridViewRow currentRow = dgv_product.CurrentRow;
            dgv_product.Rows.Remove(currentRow);

            ClearDetail();
        }

        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            int categoryEditNotFound = 0;
            if (!cmbBox_category.Items.Contains(cmbBox_category.Text))
            {
                categoryEditNotFound++;
            }

            if (tBox_namaProduct.Text == "" && cmbBox_category.Text == "" && tBox_harga.Text == "" && tBox_stock.Text == "")
            {
                MessageBox.Show($"Input produk yang mau di-edit terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(cmbBox_category.Text == "" || categoryEditNotFound != 0)
            {
                MessageBox.Show("Pilih kategori terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ClearDetail();
            }
            else if (tBox_namaProduct.Text == "" || tBox_harga.Text == "" || tBox_stock.Text == "")
            {
                MessageBox.Show($"Input produk yang mau di-edit terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ClearDetail();
            }
            else
            {
                if (cmbBox_filter.Text != "")
                {
                    if (tBox_stock.Text != "0")
                    {
                        dgv_product.DataSource = dataProductSimpan;

                        for (int i = 0; i < dataProductSimpan.Rows.Count; i++)
                        {
                            if (dataProductSimpan.Rows[i][0].ToString() == dataProductTampil.Rows[indexProductCurrentRow][0].ToString())
                            {
                                dataProductSimpan.Rows[i][1] = tBox_namaProduct.Text;
                                dataProductSimpan.Rows[i][2] = tBox_harga.Text;
                                dataProductSimpan.Rows[i][3] = tBox_stock.Text;
                                CheckCategoryID();
                                dataProductSimpan.Rows[i][4] = categoryID;
                            }
                        }

                        cmbBox_filter.Text = "";
                        ClearDetail();
                    }
                    else
                    {
                        removeProductFilter();
                    }
                }
                else
                {
                    if (tBox_stock.Text != "0")
                    {
                        dgv_product.Rows[indexProductCurrentRow].Cells[1].Value = tBox_namaProduct.Text;
                        dgv_product.Rows[indexProductCurrentRow].Cells[2].Value = tBox_harga.Text;
                        dgv_product.Rows[indexProductCurrentRow].Cells[3].Value = tBox_stock.Text;
                        CheckCategoryID();
                        dgv_product.Rows[indexProductCurrentRow].Cells[4].Value = categoryID;

                        ClearDetail();
                    }
                    else
                    {
                        removeProductAll();
                    }
                }
            }
        }

        private void CheckCategoryID()
        {
            for (int i = 0; i < dgv_category.Rows.Count; i++)
            {
                if (cmbBox_category.Text == dgv_category.Rows[i].Cells[1].Value.ToString())
                {
                    categoryID = dgv_category.Rows[i].Cells[0].Value.ToString();
                }
            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cmbBox_filter.Text = "";
            cmbBox_filter.Enabled = false;
            dgv_product.DataSource = dataProductSimpan;
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cmbBox_filter.Enabled = true;
        }

        private void cmbBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataProductTampil = new DataTable();
            dataProductTampil.Columns.Add("ID Product");
            dataProductTampil.Columns.Add("Nama Product");
            dataProductTampil.Columns.Add("Harga");
            dataProductTampil.Columns.Add("Stock");
            dataProductTampil.Columns.Add("ID Category");
            dgv_product.DataSource = dataProductTampil;

            for (int i = 0; i < dataCategories.Rows.Count; i++)
            {
                if (dataCategories.Rows[i][1].ToString() == cmbBox_filter.Text)
                {
                    filter = dataCategories.Rows[i][0].ToString();
                }
            }

            for (int i = 0; i < dataProductSimpan.Rows.Count; i++)
            {
                if (dataProductSimpan.Rows[i][4].ToString().Contains(filter))
                {
                    dataProductTampil.Rows.Add(dataProductSimpan.Rows[i][0].ToString(), dataProductSimpan.Rows[i][1].ToString(), dataProductSimpan.Rows[i][2].ToString(), dataProductSimpan.Rows[i][3].ToString(), dataProductSimpan.Rows[i][4].ToString());
                }
            }
        }
    }
}