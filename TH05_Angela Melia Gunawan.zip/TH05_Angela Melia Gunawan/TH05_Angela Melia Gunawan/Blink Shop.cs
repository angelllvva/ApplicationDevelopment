﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Angela_Melia_Gunawan
{
    public partial class Blink_Shop : Form
    {
        string blinkShopTitle = "Welcome to Blink Shop";
        string currentText = "";

        Timer timerEnter = new Timer();

        public Blink_Shop()
        {
            InitializeComponent();
        }

        private void btn_skip_Click(object sender, EventArgs e)
        {
            Main_Menu form3 = new Main_Menu();
            form3.Show();

            this.Hide();
        }

        private void Blink_Shop_Load(object sender, EventArgs e)
        {
            TypeWriterEffect();

            timerEnter.Interval = 500;
            timerEnter.Tick += timer_pressEnter_Tick;
            timerEnter.Start();
        }

        private void timer_pressEnter_Tick(object sender, EventArgs e)
        {
            lb_pressEnter.Visible = !lb_pressEnter.Visible;
        }

        private void tBox_enterName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                pnl_BlinkShop2.Visible = true;
                pnl_BlinkShop.Visible = false;
                if (tBox_enterName.Text == "")
                {
                    lb_name.Text = "...";
                }
                else
                {
                    lb_name.Text = tBox_enterName.Text;
                }
            }
        }

        private async void btn_shopNow_Click(object sender, EventArgs e)
        {
            progressBar.Visible = true;
            progressBar.Enabled = true;

            await Task.Delay(1000);

            Main_Menu form3 = new Main_Menu();
            form3.Show();

            this.Hide();
        }

        public async void TypeWriterEffect()
        {
            for (int i = 0; i <= blinkShopTitle.Length; i++)
            {
                currentText = blinkShopTitle.Substring(0, i);
                lb_blinkShop.Text = currentText;
                await Task.Delay(200);
            }
        }
    }
}