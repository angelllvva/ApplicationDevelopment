﻿namespace TH05_Angela_Melia_Gunawan
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Menu));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lb_productTitle = new System.Windows.Forms.Label();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.lb_categoryTitle = new System.Windows.Forms.Label();
            this.lb_detailsTitle = new System.Windows.Forms.Label();
            this.lb_namaProduk = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.tBox_namaProduct = new System.Windows.Forms.TextBox();
            this.cmbBox_category = new System.Windows.Forms.ComboBox();
            this.tBox_harga = new System.Windows.Forms.TextBox();
            this.tBox_stock = new System.Windows.Forms.TextBox();
            this.btn_editProduct = new System.Windows.Forms.Button();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.lb_namaCategory = new System.Windows.Forms.Label();
            this.tBox_namaCategory = new System.Windows.Forms.TextBox();
            this.pictureBox_MainMenu = new System.Windows.Forms.PictureBox();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cmbBox_filter = new System.Windows.Forms.ComboBox();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_MainMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_productTitle
            // 
            this.lb_productTitle.AutoSize = true;
            this.lb_productTitle.BackColor = System.Drawing.Color.Transparent;
            this.lb_productTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_productTitle.Location = new System.Drawing.Point(29, 24);
            this.lb_productTitle.Name = "lb_productTitle";
            this.lb_productTitle.Size = new System.Drawing.Size(86, 25);
            this.lb_productTitle.TabIndex = 0;
            this.lb_productTitle.Text = "Product";
            // 
            // dgv_product
            // 
            this.dgv_product.AllowUserToAddRows = false;
            this.dgv_product.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_product.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_product.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_product.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_product.Location = new System.Drawing.Point(34, 67);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_product.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_product.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv_product.RowTemplate.Height = 28;
            this.dgv_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_product.Size = new System.Drawing.Size(578, 353);
            this.dgv_product.TabIndex = 1;
            this.dgv_product.Click += new System.EventHandler(this.dgv_product_Click);
            // 
            // lb_categoryTitle
            // 
            this.lb_categoryTitle.AutoSize = true;
            this.lb_categoryTitle.BackColor = System.Drawing.Color.Transparent;
            this.lb_categoryTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_categoryTitle.Location = new System.Drawing.Point(644, 24);
            this.lb_categoryTitle.Name = "lb_categoryTitle";
            this.lb_categoryTitle.Size = new System.Drawing.Size(100, 25);
            this.lb_categoryTitle.TabIndex = 2;
            this.lb_categoryTitle.Text = "Category";
            // 
            // lb_detailsTitle
            // 
            this.lb_detailsTitle.AutoSize = true;
            this.lb_detailsTitle.BackColor = System.Drawing.Color.Transparent;
            this.lb_detailsTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_detailsTitle.Location = new System.Drawing.Point(29, 439);
            this.lb_detailsTitle.Name = "lb_detailsTitle";
            this.lb_detailsTitle.Size = new System.Drawing.Size(78, 25);
            this.lb_detailsTitle.TabIndex = 4;
            this.lb_detailsTitle.Text = "Details";
            // 
            // lb_namaProduk
            // 
            this.lb_namaProduk.AutoSize = true;
            this.lb_namaProduk.Location = new System.Drawing.Point(30, 479);
            this.lb_namaProduk.Name = "lb_namaProduk";
            this.lb_namaProduk.Size = new System.Drawing.Size(59, 20);
            this.lb_namaProduk.TabIndex = 5;
            this.lb_namaProduk.Text = "Nama :";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Location = new System.Drawing.Point(30, 512);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(81, 20);
            this.lb_category.TabIndex = 6;
            this.lb_category.Text = "Category :";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(30, 548);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(61, 20);
            this.lb_harga.TabIndex = 7;
            this.lb_harga.Text = "Harga :";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Location = new System.Drawing.Point(30, 582);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(58, 20);
            this.lb_stock.TabIndex = 8;
            this.lb_stock.Text = "Stock :";
            // 
            // tBox_namaProduct
            // 
            this.tBox_namaProduct.Location = new System.Drawing.Point(129, 476);
            this.tBox_namaProduct.Name = "tBox_namaProduct";
            this.tBox_namaProduct.Size = new System.Drawing.Size(483, 26);
            this.tBox_namaProduct.TabIndex = 9;
            // 
            // cmbBox_category
            // 
            this.cmbBox_category.FormattingEnabled = true;
            this.cmbBox_category.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.cmbBox_category.Location = new System.Drawing.Point(129, 509);
            this.cmbBox_category.Name = "cmbBox_category";
            this.cmbBox_category.Size = new System.Drawing.Size(203, 28);
            this.cmbBox_category.TabIndex = 10;
            // 
            // tBox_harga
            // 
            this.tBox_harga.Location = new System.Drawing.Point(129, 545);
            this.tBox_harga.Name = "tBox_harga";
            this.tBox_harga.Size = new System.Drawing.Size(203, 26);
            this.tBox_harga.TabIndex = 11;
            this.tBox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_harga_KeyPress);
            // 
            // tBox_stock
            // 
            this.tBox_stock.Location = new System.Drawing.Point(129, 579);
            this.tBox_stock.Name = "tBox_stock";
            this.tBox_stock.Size = new System.Drawing.Size(203, 26);
            this.tBox_stock.TabIndex = 12;
            this.tBox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_stock_KeyPress);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editProduct.Location = new System.Drawing.Point(442, 542);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(82, 63);
            this.btn_editProduct.TabIndex = 15;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = false;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addProduct.Location = new System.Drawing.Point(354, 542);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(82, 63);
            this.btn_addProduct.TabIndex = 16;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeProduct.Location = new System.Drawing.Point(530, 542);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(82, 63);
            this.btn_removeProduct.TabIndex = 17;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addCategory.Location = new System.Drawing.Point(742, 357);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(96, 63);
            this.btn_addCategory.TabIndex = 18;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // lb_namaCategory
            // 
            this.lb_namaCategory.AutoSize = true;
            this.lb_namaCategory.Location = new System.Drawing.Point(645, 316);
            this.lb_namaCategory.Name = "lb_namaCategory";
            this.lb_namaCategory.Size = new System.Drawing.Size(59, 20);
            this.lb_namaCategory.TabIndex = 20;
            this.lb_namaCategory.Text = "Nama :";
            // 
            // tBox_namaCategory
            // 
            this.tBox_namaCategory.Location = new System.Drawing.Point(710, 316);
            this.tBox_namaCategory.Name = "tBox_namaCategory";
            this.tBox_namaCategory.Size = new System.Drawing.Size(230, 26);
            this.tBox_namaCategory.TabIndex = 21;
            // 
            // pictureBox_MainMenu
            // 
            this.pictureBox_MainMenu.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_MainMenu.Image")));
            this.pictureBox_MainMenu.Location = new System.Drawing.Point(681, 454);
            this.pictureBox_MainMenu.Name = "pictureBox_MainMenu";
            this.pictureBox_MainMenu.Size = new System.Drawing.Size(227, 192);
            this.pictureBox_MainMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_MainMenu.TabIndex = 22;
            this.pictureBox_MainMenu.TabStop = false;
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.Red;
            this.btn_removeCategory.Location = new System.Drawing.Point(844, 357);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(96, 63);
            this.btn_removeCategory.TabIndex = 23;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(342, 21);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(52, 32);
            this.btn_all.TabIndex = 24;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(400, 21);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(70, 32);
            this.btn_filter.TabIndex = 25;
            this.btn_filter.Text = "Filter :";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cmbBox_filter
            // 
            this.cmbBox_filter.Enabled = false;
            this.cmbBox_filter.FormattingEnabled = true;
            this.cmbBox_filter.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.cmbBox_filter.Location = new System.Drawing.Point(476, 21);
            this.cmbBox_filter.Name = "cmbBox_filter";
            this.cmbBox_filter.Size = new System.Drawing.Size(136, 28);
            this.cmbBox_filter.TabIndex = 26;
            this.cmbBox_filter.SelectedIndexChanged += new System.EventHandler(this.cmbBox_filter_SelectedIndexChanged);
            // 
            // dgv_category
            // 
            this.dgv_category.AllowUserToAddRows = false;
            this.dgv_category.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_category.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_category.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_category.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_category.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dgv_category.Location = new System.Drawing.Point(649, 67);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_category.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_category.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_category.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_category.RowTemplate.Height = 28;
            this.dgv_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_category.Size = new System.Drawing.Size(291, 226);
            this.dgv_category.TabIndex = 27;
            this.dgv_category.Click += new System.EventHandler(this.dgv_category_Click);
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(978, 636);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.cmbBox_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.pictureBox_MainMenu);
            this.Controls.Add(this.tBox_namaCategory);
            this.Controls.Add(this.lb_namaCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.tBox_stock);
            this.Controls.Add(this.tBox_harga);
            this.Controls.Add(this.cmbBox_category);
            this.Controls.Add(this.tBox_namaProduct);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_namaProduk);
            this.Controls.Add(this.lb_detailsTitle);
            this.Controls.Add(this.lb_categoryTitle);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.lb_productTitle);
            this.MaximumSize = new System.Drawing.Size(1000, 692);
            this.Name = "Main_Menu";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Main_Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_MainMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_productTitle;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.Label lb_categoryTitle;
        private System.Windows.Forms.Label lb_detailsTitle;
        private System.Windows.Forms.Label lb_namaProduk;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.TextBox tBox_namaProduct;
        private System.Windows.Forms.ComboBox cmbBox_category;
        private System.Windows.Forms.TextBox tBox_harga;
        private System.Windows.Forms.TextBox tBox_stock;
        private System.Windows.Forms.Button btn_editProduct;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Label lb_namaCategory;
        private System.Windows.Forms.TextBox tBox_namaCategory;
        private System.Windows.Forms.PictureBox pictureBox_MainMenu;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cmbBox_filter;
        private System.Windows.Forms.DataGridView dgv_category;
    }
}