﻿namespace TH05_Angela_Melia_Gunawan
{
    partial class Blink_Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Blink_Shop));
            this.lb_blinkShop = new System.Windows.Forms.Label();
            this.btn_skip = new System.Windows.Forms.Button();
            this.timer_pressEnter = new System.Windows.Forms.Timer(this.components);
            this.pnl_BlinkShop = new System.Windows.Forms.Panel();
            this.lb_pressEnter = new System.Windows.Forms.Label();
            this.tBox_enterName = new System.Windows.Forms.TextBox();
            this.lb_enterName = new System.Windows.Forms.Label();
            this.pnl_BlinkShop2 = new System.Windows.Forms.Panel();
            this.lb_name = new System.Windows.Forms.Label();
            this.btn_shopNow = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.pnl_Welcome1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Welcome1 = new System.Windows.Forms.PictureBox();
            this.pnl_Welcome2 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Welcome2 = new System.Windows.Forms.PictureBox();
            this.pnl_BlinkShop.SuspendLayout();
            this.pnl_BlinkShop2.SuspendLayout();
            this.pnl_Welcome1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Welcome1)).BeginInit();
            this.pnl_Welcome2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Welcome2)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_blinkShop
            // 
            this.lb_blinkShop.AutoSize = true;
            this.lb_blinkShop.BackColor = System.Drawing.Color.Transparent;
            this.lb_blinkShop.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blinkShop.Location = new System.Drawing.Point(189, 98);
            this.lb_blinkShop.Name = "lb_blinkShop";
            this.lb_blinkShop.Size = new System.Drawing.Size(0, 45);
            this.lb_blinkShop.TabIndex = 0;
            // 
            // btn_skip
            // 
            this.btn_skip.BackColor = System.Drawing.Color.Coral;
            this.btn_skip.Location = new System.Drawing.Point(702, 10);
            this.btn_skip.Name = "btn_skip";
            this.btn_skip.Size = new System.Drawing.Size(88, 35);
            this.btn_skip.TabIndex = 5;
            this.btn_skip.Text = "Skip";
            this.btn_skip.UseVisualStyleBackColor = false;
            this.btn_skip.Click += new System.EventHandler(this.btn_skip_Click);
            // 
            // timer_pressEnter
            // 
            this.timer_pressEnter.Tick += new System.EventHandler(this.timer_pressEnter_Tick);
            // 
            // pnl_BlinkShop
            // 
            this.pnl_BlinkShop.Controls.Add(this.lb_pressEnter);
            this.pnl_BlinkShop.Controls.Add(this.tBox_enterName);
            this.pnl_BlinkShop.Controls.Add(this.lb_enterName);
            this.pnl_BlinkShop.Location = new System.Drawing.Point(295, 192);
            this.pnl_BlinkShop.Name = "pnl_BlinkShop";
            this.pnl_BlinkShop.Size = new System.Drawing.Size(200, 100);
            this.pnl_BlinkShop.TabIndex = 7;
            // 
            // lb_pressEnter
            // 
            this.lb_pressEnter.AutoSize = true;
            this.lb_pressEnter.BackColor = System.Drawing.Color.Transparent;
            this.lb_pressEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pressEnter.Location = new System.Drawing.Point(51, 73);
            this.lb_pressEnter.Name = "lb_pressEnter";
            this.lb_pressEnter.Size = new System.Drawing.Size(91, 17);
            this.lb_pressEnter.TabIndex = 9;
            this.lb_pressEnter.Text = "(press Enter)";
            this.lb_pressEnter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_pressEnter.Visible = false;
            // 
            // tBox_enterName
            // 
            this.tBox_enterName.BackColor = System.Drawing.Color.White;
            this.tBox_enterName.Location = new System.Drawing.Point(16, 40);
            this.tBox_enterName.Name = "tBox_enterName";
            this.tBox_enterName.Size = new System.Drawing.Size(172, 26);
            this.tBox_enterName.TabIndex = 8;
            this.tBox_enterName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tBox_enterName_KeyDown);
            // 
            // lb_enterName
            // 
            this.lb_enterName.AutoSize = true;
            this.lb_enterName.BackColor = System.Drawing.Color.Transparent;
            this.lb_enterName.Location = new System.Drawing.Point(12, 10);
            this.lb_enterName.Name = "lb_enterName";
            this.lb_enterName.Size = new System.Drawing.Size(176, 20);
            this.lb_enterName.TabIndex = 7;
            this.lb_enterName.Text = "Please enter your name";
            this.lb_enterName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_BlinkShop2
            // 
            this.pnl_BlinkShop2.Controls.Add(this.lb_name);
            this.pnl_BlinkShop2.Controls.Add(this.btn_shopNow);
            this.pnl_BlinkShop2.Location = new System.Drawing.Point(247, 146);
            this.pnl_BlinkShop2.Name = "pnl_BlinkShop2";
            this.pnl_BlinkShop2.Size = new System.Drawing.Size(335, 219);
            this.pnl_BlinkShop2.TabIndex = 13;
            this.pnl_BlinkShop2.Visible = false;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.Location = new System.Drawing.Point(77, 21);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(50, 45);
            this.lb_name.TabIndex = 14;
            this.lb_name.Text = "...";
            this.lb_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_shopNow
            // 
            this.btn_shopNow.Location = new System.Drawing.Point(76, 106);
            this.btn_shopNow.Name = "btn_shopNow";
            this.btn_shopNow.Size = new System.Drawing.Size(135, 35);
            this.btn_shopNow.TabIndex = 13;
            this.btn_shopNow.Text = "Shop Now!";
            this.btn_shopNow.UseVisualStyleBackColor = true;
            this.btn_shopNow.Click += new System.EventHandler(this.btn_shopNow_Click);
            // 
            // progressBar
            // 
            this.progressBar.Enabled = false;
            this.progressBar.ForeColor = System.Drawing.Color.Green;
            this.progressBar.Location = new System.Drawing.Point(-2, 371);
            this.progressBar.Maximum = 30;
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(804, 27);
            this.progressBar.TabIndex = 14;
            this.progressBar.Value = 22;
            this.progressBar.Visible = false;
            // 
            // pnl_Welcome1
            // 
            this.pnl_Welcome1.Controls.Add(this.pictureBox2);
            this.pnl_Welcome1.Controls.Add(this.pictureBox1);
            this.pnl_Welcome1.Controls.Add(this.pictureBox_Welcome1);
            this.pnl_Welcome1.Location = new System.Drawing.Point(13, 51);
            this.pnl_Welcome1.Name = "pnl_Welcome1";
            this.pnl_Welcome1.Size = new System.Drawing.Size(200, 314);
            this.pnl_Welcome1.TabIndex = 15;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(94, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(47, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(29, 56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox_Welcome1
            // 
            this.pictureBox_Welcome1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Welcome1.Image")));
            this.pictureBox_Welcome1.Location = new System.Drawing.Point(0, 127);
            this.pictureBox_Welcome1.Name = "pictureBox_Welcome1";
            this.pictureBox_Welcome1.Size = new System.Drawing.Size(200, 187);
            this.pictureBox_Welcome1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Welcome1.TabIndex = 1;
            this.pictureBox_Welcome1.TabStop = false;
            // 
            // pnl_Welcome2
            // 
            this.pnl_Welcome2.Controls.Add(this.pictureBox4);
            this.pnl_Welcome2.Controls.Add(this.pictureBox3);
            this.pnl_Welcome2.Controls.Add(this.pictureBox_Welcome2);
            this.pnl_Welcome2.Location = new System.Drawing.Point(581, 51);
            this.pnl_Welcome2.Name = "pnl_Welcome2";
            this.pnl_Welcome2.Size = new System.Drawing.Size(200, 314);
            this.pnl_Welcome2.TabIndex = 16;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(131, 56);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(47, 42);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(62, 34);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(47, 42);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox_Welcome2
            // 
            this.pictureBox_Welcome2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Welcome2.Image")));
            this.pictureBox_Welcome2.Location = new System.Drawing.Point(0, 127);
            this.pictureBox_Welcome2.Name = "pictureBox_Welcome2";
            this.pictureBox_Welcome2.Size = new System.Drawing.Size(200, 187);
            this.pictureBox_Welcome2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Welcome2.TabIndex = 0;
            this.pictureBox_Welcome2.TabStop = false;
            // 
            // Blink_Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(800, 394);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.pnl_BlinkShop2);
            this.Controls.Add(this.btn_skip);
            this.Controls.Add(this.lb_blinkShop);
            this.Controls.Add(this.pnl_BlinkShop);
            this.Controls.Add(this.pnl_Welcome1);
            this.Controls.Add(this.pnl_Welcome2);
            this.MaximumSize = new System.Drawing.Size(822, 450);
            this.Name = "Blink_Shop";
            this.Text = "Welcome";
            this.Load += new System.EventHandler(this.Blink_Shop_Load);
            this.pnl_BlinkShop.ResumeLayout(false);
            this.pnl_BlinkShop.PerformLayout();
            this.pnl_BlinkShop2.ResumeLayout(false);
            this.pnl_BlinkShop2.PerformLayout();
            this.pnl_Welcome1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Welcome1)).EndInit();
            this.pnl_Welcome2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Welcome2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_blinkShop;
        private System.Windows.Forms.Button btn_skip;
        private System.Windows.Forms.Timer timer_pressEnter;
        private System.Windows.Forms.Panel pnl_BlinkShop;
        private System.Windows.Forms.Label lb_pressEnter;
        private System.Windows.Forms.TextBox tBox_enterName;
        private System.Windows.Forms.Label lb_enterName;
        private System.Windows.Forms.Panel pnl_BlinkShop2;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Button btn_shopNow;
        private System.Windows.Forms.Panel pnl_Welcome1;
        private System.Windows.Forms.Panel pnl_Welcome2;
        private System.Windows.Forms.PictureBox pictureBox_Welcome2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox_Welcome1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

