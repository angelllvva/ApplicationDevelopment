﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14_Angela_Melia_Gunawan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        string sqlQuery;
        string matchDate;

        int goalHome = 0;
        int goalAway = 0;

        DataTable dt_match;
        DataTable dt_matchDate;
        DataTable dt_teamHome;
        DataTable dt_teamAway;
        DataTable dt_team;
        DataTable dt_player;
        DataTable dt_type;
        DataTable dt_dgv;
        DataTable dt_dmatch;

        private void Form1_Load(object sender, EventArgs e)
        {
            dt_dgv = new DataTable();
            dt_dgv.Columns.Add("Team");
            dt_dgv.Columns.Add("Player");
            dt_dgv.Columns.Add("Type");

            dt_dmatch = new DataTable();
            dt_dmatch.Columns.Add("Match ID");
            dt_dmatch.Columns.Add("Minute");
            dt_dmatch.Columns.Add("Team ID");
            dt_dmatch.Columns.Add("Player ID");
            dt_dmatch.Columns.Add("Type");

            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Angela0323*;database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();

            sqlQuery = "SELECT team_id, team_name FROM team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

            dt_teamHome = new DataTable();
            dt_teamAway = new DataTable();
            sqlDataAdapter.Fill(dt_teamHome);
            sqlDataAdapter.Fill(dt_teamAway);

            cmb_teamHome.DataSource = dt_teamHome;
            cmb_teamHome.DisplayMember = "team_name";
            cmb_teamHome.ValueMember = "team_id";

            cmb_teamHome.Text = "";

            cmb_teamAway.DataSource = dt_teamAway;
            cmb_teamAway.DisplayMember = "team_name";
            cmb_teamAway.ValueMember = "team_id";

            cmb_teamAway.Text = "";

            dt_type = new DataTable();
            dt_type.Columns.Add("Type ID");
            dt_type.Columns.Add("Type Name");

            dt_type.Rows.Add("GO", "Goal");
            dt_type.Rows.Add("GP", "Goal Penalty");
            dt_type.Rows.Add("GW", "Own Goal");
            dt_type.Rows.Add("CR", "Red Card");
            dt_type.Rows.Add("CY", "Yellow Card");
            dt_type.Rows.Add("PM", "Penalty Miss");

            cmb_type.DataSource = dt_type;
            cmb_type.DisplayMember = "Type Name";
            cmb_type.ValueMember = "Type ID";

            cmb_team.Text = "";
            cmb_player.Text = "";
            cmb_type.Text = "";
        }

        private void dateTimePicker_matchDate_ValueChanged(object sender, EventArgs e)
        {
            dt_match = new DataTable();
            sqlQuery = $"SELECT match_date FROM `match`";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_match);

            matchDate = dateTimePicker_matchDate.Value.Year.ToString() + '-' + dateTimePicker_matchDate.Value.Month.ToString() + '-' + dateTimePicker_matchDate.Value.Day.ToString();

            if (dateTimePicker_matchDate.Value < Convert.ToDateTime(dt_match.Rows[dt_match.Rows.Count - 1][0].ToString()))
            {
                MessageBox.Show($"Date cannot be before the last match date", "Error");
            }
            else
            {
                sqlQuery = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{dateTimePicker_matchDate.Value.Year}%'";
                dt_matchDate = new DataTable();
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt_matchDate);

                int lastMatchIDNumber = Convert.ToInt32(dt_matchDate.Rows[0][0]) + 1;

                if (lastMatchIDNumber < 10)
                {
                    tBox_matchID.Text = $"{dateTimePicker_matchDate.Value.Year}00{lastMatchIDNumber}";
                }
                else if (lastMatchIDNumber < 100)
                {
                    tBox_matchID.Text = $"{dateTimePicker_matchDate.Value.Year}0{lastMatchIDNumber}";
                }
                else
                {
                    tBox_matchID.Text = $"{dateTimePicker_matchDate.Value.Year}{lastMatchIDNumber}";
                }
            }
        }

        private void cmb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dt_dgv.Rows.Count != 0 && dt_dmatch.Rows.Count != 0)
            {
                dt_dgv.Rows.Clear();
                dt_dmatch.Rows.Clear();
            }

            if (cmb_teamHome.Text == cmb_teamAway.Text)
            {
                MessageBox.Show("Cannot choose the same team", "Error");

                cmb_teamHome.Text = "";
                cmb_teamAway.Text = "";
            }
            else if(cmb_teamHome.Text != "" && cmb_teamAway.Text != "")
            {
                dt_team = new DataTable();
                sqlQuery = $"SELECT team_id, team_name FROM team WHERE team_id = '{cmb_teamHome.SelectedValue}' OR team_id = '{cmb_teamAway.SelectedValue}'";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt_team);

                cmb_team.DataSource = dt_team;
                cmb_team.DisplayMember = "team_name";
                cmb_team.ValueMember = "team_id";

                cmb_team.Text = "";
            }
        }

        private void cmb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dt_dgv.Rows.Count != 0 && dt_dmatch.Rows.Count != 0)
            {
                dt_dgv.Rows.Clear();
                dt_dmatch.Rows.Clear();
            }

            if (cmb_teamHome.Text == cmb_teamAway.Text)
            {
                MessageBox.Show("Cannot choose the same team", "Error");

                cmb_teamHome.Text = "";
                cmb_teamAway.Text = "";
            }
            else if (cmb_teamHome.Text != "" && cmb_teamAway.Text != "")
            {
                dt_team = new DataTable();
                sqlQuery = $"SELECT team_id, team_name FROM team WHERE team_id = '{cmb_teamHome.SelectedValue}' OR team_id = '{cmb_teamAway.SelectedValue}'";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt_team);

                cmb_team.DataSource = dt_team;
                cmb_team.DisplayMember = "team_name";
                cmb_team.ValueMember = "team_id";

                cmb_team.Text = "";
            }
        }

        private void cmb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt_player = new DataTable();
            sqlQuery = $"SELECT player_id, player_name FROM player WHERE team_id = '{cmb_team.SelectedValue}'";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_player);

            cmb_player.DataSource = dt_player;
            cmb_player.DisplayMember = "player_name";
            cmb_player.ValueMember = "player_id";

            cmb_player.Text = "";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tBox_minute.Text == "" || cmb_team.Text == "" || cmb_player.Text == "" || cmb_type.Text == "" || tBox_matchID.Text == "")
            {
                MessageBox.Show("All fields need to be inputted", "Error");
            }
            else
            {
                if (cmb_type.SelectedValue == "GO" || cmb_type.SelectedValue == "GP")
                {
                    if (cmb_teamAway.Text == cmb_team.Text)
                    {
                        goalAway++;
                    }
                    else
                    {
                        goalHome++;
                    }
                }
                else if (cmb_type.SelectedValue == "GW")
                {
                    if (cmb_teamAway.Text == cmb_team.Text)
                    {
                        goalHome++;
                    }
                    else
                    {
                        goalAway++;
                    }
                }

                dt_dmatch.Rows.Add(tBox_matchID.Text, tBox_minute.Text, cmb_team.SelectedValue, cmb_player.SelectedValue, cmb_type.SelectedValue);
                dgv_dmatch.DataSource = dt_dmatch;

                dt_dgv.Rows.Add(cmb_team.Text, cmb_player.Text, cmb_type.SelectedValue);
                dgv_data.DataSource = dt_dgv;

                dgv_data.ClearSelection();

                tBox_minute.Text = "";
                cmb_team.Text = "";
                cmb_player.Text = "";
                cmb_type.Text = "";
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dt_dgv.Rows.Count == 0)
            {
                MessageBox.Show("There's no row to be removed", "Error");
            }
            else
            {
                dgv_data.ClearSelection();

                DataGridViewRow currentRow = dgv_data.CurrentRow;
                int indexRemove = 0;

                if (dgv_data.Rows.Count != 0)
                {
                    for (int i = 0; i < dt_dgv.Rows.Count; i++)
                    {
                        if (dt_dgv.Rows[i][0].ToString().Contains(currentRow.Cells[0].Value.ToString()))
                        {
                            indexRemove = i;
                        }
                    }

                    if (currentRow.Cells[2].Value.ToString() == "GO" || currentRow.Cells[2].Value.ToString() == "GP")
                    {
                        if (cmb_teamAway.Text == dt_dgv.Rows[indexRemove][0].ToString())
                        {
                            goalAway--;
                        }
                        else
                        {
                            goalHome--;
                        }
                    }
                    else if (currentRow.Cells[2].Value.ToString() == "GW")
                    {
                        if (cmb_teamAway.Text == dt_dgv.Rows[indexRemove][0].ToString())
                        {
                            goalHome--;
                        }
                        else
                        {
                            goalAway--;
                        }
                    }

                    dt_dgv.Rows.RemoveAt(indexRemove);
                    dt_dmatch.Rows.RemoveAt(indexRemove);
                }

                dgv_data.DataSource = dt_dgv;
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (dt_dmatch.Rows.Count == 0)
            {
                MessageBox.Show("There's no data to be inserted", "Error");
            }
            else
            {
                for (int i = 0; i < dt_dmatch.Rows.Count; i++)
                {
                    sqlQuery = $"INSERT INTO dmatch VALUES ('{dt_dmatch.Rows[i][0]}', '{dt_dmatch.Rows[i][1]}', '{dt_dmatch.Rows[i][2]}', '{dt_dmatch.Rows[i][3]}', '{dt_dmatch.Rows[i][4]}', '0')";
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }

                sqlQuery = $"INSERT INTO `match` VALUES ('{tBox_matchID.Text}', '{matchDate}', '{cmb_teamHome.SelectedValue}', '{cmb_teamAway.SelectedValue}', '{goalHome.ToString()}', '{goalAway.ToString()}', 'M002', '0');";
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();

                dt_dgv.Rows.Clear();
                dt_dmatch.Rows.Clear();

                tBox_matchID.Text = "";
                cmb_teamHome.Text = "";
                cmb_teamAway.Text = "";
            }
        }

        private void tBox_minute_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}