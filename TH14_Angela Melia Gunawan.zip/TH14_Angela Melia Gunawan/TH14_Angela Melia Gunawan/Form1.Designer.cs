﻿namespace TH14_Angela_Melia_Gunawan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.tBox_matchID = new System.Windows.Forms.TextBox();
            this.lb_matchID = new System.Windows.Forms.Label();
            this.lb_teamHome = new System.Windows.Forms.Label();
            this.lb_matchDate = new System.Windows.Forms.Label();
            this.lb_teamAway = new System.Windows.Forms.Label();
            this.cmb_teamHome = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_matchDate = new System.Windows.Forms.DateTimePicker();
            this.cmb_teamAway = new System.Windows.Forms.ComboBox();
            this.lb_minute = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.tBox_minute = new System.Windows.Forms.TextBox();
            this.cmb_team = new System.Windows.Forms.ComboBox();
            this.cmb_player = new System.Windows.Forms.ComboBox();
            this.cmb_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_data
            // 
            this.dgv_data.AllowUserToAddRows = false;
            this.dgv_data.AllowUserToDeleteRows = false;
            this.dgv_data.AllowUserToResizeColumns = false;
            this.dgv_data.AllowUserToResizeRows = false;
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(32, 127);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 62;
            this.dgv_data.RowTemplate.Height = 28;
            this.dgv_data.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_data.Size = new System.Drawing.Size(546, 247);
            this.dgv_data.TabIndex = 0;
            // 
            // tBox_matchID
            // 
            this.tBox_matchID.Enabled = false;
            this.tBox_matchID.Location = new System.Drawing.Point(147, 25);
            this.tBox_matchID.Name = "tBox_matchID";
            this.tBox_matchID.Size = new System.Drawing.Size(176, 26);
            this.tBox_matchID.TabIndex = 1;
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(28, 28);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(74, 20);
            this.lb_matchID.TabIndex = 2;
            this.lb_matchID.Text = "Match ID";
            // 
            // lb_teamHome
            // 
            this.lb_teamHome.AutoSize = true;
            this.lb_teamHome.Location = new System.Drawing.Point(28, 68);
            this.lb_teamHome.Name = "lb_teamHome";
            this.lb_teamHome.Size = new System.Drawing.Size(96, 20);
            this.lb_teamHome.TabIndex = 3;
            this.lb_teamHome.Text = "Team Home";
            // 
            // lb_matchDate
            // 
            this.lb_matchDate.AutoSize = true;
            this.lb_matchDate.Location = new System.Drawing.Point(389, 28);
            this.lb_matchDate.Name = "lb_matchDate";
            this.lb_matchDate.Size = new System.Drawing.Size(92, 20);
            this.lb_matchDate.TabIndex = 4;
            this.lb_matchDate.Text = "Match Date";
            // 
            // lb_teamAway
            // 
            this.lb_teamAway.AutoSize = true;
            this.lb_teamAway.Location = new System.Drawing.Point(389, 68);
            this.lb_teamAway.Name = "lb_teamAway";
            this.lb_teamAway.Size = new System.Drawing.Size(91, 20);
            this.lb_teamAway.TabIndex = 5;
            this.lb_teamAway.Text = "Team Away";
            // 
            // cmb_teamHome
            // 
            this.cmb_teamHome.FormattingEnabled = true;
            this.cmb_teamHome.Location = new System.Drawing.Point(147, 65);
            this.cmb_teamHome.Name = "cmb_teamHome";
            this.cmb_teamHome.Size = new System.Drawing.Size(176, 28);
            this.cmb_teamHome.TabIndex = 6;
            this.cmb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cmb_teamHome_SelectedIndexChanged);
            // 
            // dateTimePicker_matchDate
            // 
            this.dateTimePicker_matchDate.Location = new System.Drawing.Point(511, 25);
            this.dateTimePicker_matchDate.Name = "dateTimePicker_matchDate";
            this.dateTimePicker_matchDate.Size = new System.Drawing.Size(272, 26);
            this.dateTimePicker_matchDate.TabIndex = 7;
            this.dateTimePicker_matchDate.ValueChanged += new System.EventHandler(this.dateTimePicker_matchDate_ValueChanged);
            // 
            // cmb_teamAway
            // 
            this.cmb_teamAway.FormattingEnabled = true;
            this.cmb_teamAway.Location = new System.Drawing.Point(511, 65);
            this.cmb_teamAway.Name = "cmb_teamAway";
            this.cmb_teamAway.Size = new System.Drawing.Size(176, 28);
            this.cmb_teamAway.TabIndex = 8;
            this.cmb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cmb_teamAway_SelectedIndexChanged);
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(606, 145);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(57, 20);
            this.lb_minute.TabIndex = 9;
            this.lb_minute.Text = "Minute";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(606, 182);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(49, 20);
            this.lb_team.TabIndex = 10;
            this.lb_team.Text = "Team";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(606, 219);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(52, 20);
            this.lb_player.TabIndex = 11;
            this.lb_player.Text = "Player";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(606, 257);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(43, 20);
            this.lb_type.TabIndex = 12;
            this.lb_type.Text = "Type";
            // 
            // tBox_minute
            // 
            this.tBox_minute.Location = new System.Drawing.Point(678, 142);
            this.tBox_minute.MaxLength = 3;
            this.tBox_minute.Name = "tBox_minute";
            this.tBox_minute.Size = new System.Drawing.Size(176, 26);
            this.tBox_minute.TabIndex = 13;
            this.tBox_minute.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_minute_KeyPress);
            // 
            // cmb_team
            // 
            this.cmb_team.FormattingEnabled = true;
            this.cmb_team.Location = new System.Drawing.Point(678, 179);
            this.cmb_team.Name = "cmb_team";
            this.cmb_team.Size = new System.Drawing.Size(176, 28);
            this.cmb_team.TabIndex = 14;
            this.cmb_team.SelectedIndexChanged += new System.EventHandler(this.cmb_team_SelectedIndexChanged);
            // 
            // cmb_player
            // 
            this.cmb_player.FormattingEnabled = true;
            this.cmb_player.Location = new System.Drawing.Point(678, 216);
            this.cmb_player.Name = "cmb_player";
            this.cmb_player.Size = new System.Drawing.Size(176, 28);
            this.cmb_player.TabIndex = 15;
            // 
            // cmb_type
            // 
            this.cmb_type.FormattingEnabled = true;
            this.cmb_type.Location = new System.Drawing.Point(678, 254);
            this.cmb_type.Name = "cmb_type";
            this.cmb_type.Size = new System.Drawing.Size(176, 28);
            this.cmb_type.TabIndex = 16;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(610, 302);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(117, 30);
            this.btn_add.TabIndex = 17;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(737, 302);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(117, 30);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(355, 391);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(171, 30);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 444);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cmb_type);
            this.Controls.Add(this.cmb_player);
            this.Controls.Add(this.cmb_team);
            this.Controls.Add(this.tBox_minute);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.cmb_teamAway);
            this.Controls.Add(this.dateTimePicker_matchDate);
            this.Controls.Add(this.cmb_teamHome);
            this.Controls.Add(this.lb_teamAway);
            this.Controls.Add(this.lb_matchDate);
            this.Controls.Add(this.lb_teamHome);
            this.Controls.Add(this.lb_matchID);
            this.Controls.Add(this.tBox_matchID);
            this.Controls.Add(this.dgv_data);
            this.MaximumSize = new System.Drawing.Size(913, 500);
            this.Name = "Form1";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.TextBox tBox_matchID;
        private System.Windows.Forms.Label lb_matchID;
        private System.Windows.Forms.Label lb_teamHome;
        private System.Windows.Forms.Label lb_matchDate;
        private System.Windows.Forms.Label lb_teamAway;
        private System.Windows.Forms.ComboBox cmb_teamHome;
        private System.Windows.Forms.DateTimePicker dateTimePicker_matchDate;
        private System.Windows.Forms.ComboBox cmb_teamAway;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.TextBox tBox_minute;
        private System.Windows.Forms.ComboBox cmb_team;
        private System.Windows.Forms.ComboBox cmb_player;
        private System.Windows.Forms.ComboBox cmb_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
    }
}

